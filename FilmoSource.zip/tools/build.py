#!/usr/bin/env python3
"""Compile Kotlin, run parser checks, create Android DEX and a Cloudstream repository.

Requires Python 3.10+, Java 17+ and Node.js 18+. The CS3 archive contains only this plugin,
not the compile-time API or Android/Kotlin libraries.
"""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import subprocess
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", default=os.environ.get("GITHUB_REPOSITORY"), help="GitHub OWNER/REPO")
    ap.add_argument("--cache", type=Path, default=ROOT / ".build-cache")
    ap.add_argument("--fixtures", help="Optional directory of locally fetched HTML fixtures")
    ap.add_argument("--movie-fixture", help="Optional current movie HTML for challenge form validation")
    args = ap.parse_args()
    if args.repo and not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", args.repo):
        ap.error("--repo must have the form OWNER/REPOSITORY")
    java = shutil.which("java")
    if not java:
        raise SystemExit("Java 17 or newer is required.")
    java_info = subprocess.run([java, "-XshowSettings:properties", "-version"],
                               capture_output=True, text=True, check=True)
    home_match = re.search(r"^\s*java.home\s*=\s*(.+)$", java_info.stderr, re.MULTILINE)
    if not home_match:
        raise SystemExit("Could not determine Java runtime home.")
    java_home = home_match.group(1).strip()
    args.cache.mkdir(parents=True, exist_ok=True)
    build = ROOT / "build"
    dist = ROOT / "dist"
    build.mkdir(exist_ok=True)
    dist.mkdir(exist_ok=True)
    dependencies = json.loads((ROOT / "dependencies.json").read_text())

    def download(dep):
        target = args.cache / dep["file"]
        if target.exists() and sha256(target) == dep["sha256"]:
            return target
        temp = target.with_suffix(".download")
        request = urllib.request.Request(dep["url"], headers={"User-Agent": "FilmoIP-build/1"})
        with urllib.request.urlopen(request, timeout=90) as response, temp.open("wb") as output:
            shutil.copyfileobj(response, output)
        if sha256(temp) != dep["sha256"]:
            temp.unlink(missing_ok=True)
            raise RuntimeError("Dependency checksum changed: " + dep["file"] + ". See README before updating it.")
        temp.replace(target)
        print("Downloaded " + dep["file"], flush=True)
        return target

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(download, dependencies))

    def classpath(names):
        return os.pathsep.join(str(args.cache / name) for name in names)

    compiler = ["kotlin-compiler-2.4.jar", "kotlin-build-tools-api.jar", "kotlin-stdlib-2.4.jar",
                "kotlin-script-runtime-2.4.jar", "kotlin-reflect.jar", "kotlin-daemon-2.4.jar",
                "coroutines-1.8.jar", "annotations.jar"]
    libraries = ["cloudstream.jar", "kotlin-stdlib-2.4.jar", "coroutines-1.8.jar", "jsoup.jar",
                 "android-modern.jar", "annotations.jar"]
    compiler_cmd = [java, "-Xmx1g", "-cp", classpath(compiler), "org.jetbrains.kotlin.cli.jvm.K2JVMCompiler",
                    "-no-stdlib", "-no-reflect", "-jvm-target", "1.8",
                    "-Xno-call-assertions", "-Xno-param-assertions", "-Xno-receiver-assertions"]
    sources = sorted((ROOT / "src/main/kotlin").rglob("*.kt"))
    subprocess.run(compiler_cmd + ["-classpath", classpath(libraries), "-d", str(build / "plugin.jar")]
                   + list(map(str, sources)), check=True)

    parser = ROOT / "src/main/kotlin/com/custom/filmoip/SiteParser.kt"
    testlibs = ["kotlin-stdlib-2.4.jar", "jsoup.jar", "annotations.jar"]
    subprocess.run(compiler_cmd + ["-classpath", classpath(testlibs), "-d", str(build / "tests.jar"),
                   str(parser), str(parser.with_name("GatePage.kt")), str(parser.with_name("GateSession.kt")),
                   str(ROOT / "tests/ParserTest.kt"), str(ROOT / "tests/GateTest.kt")], check=True)
    subprocess.run([java, "-cp", str(build / "tests.jar") + os.pathsep + classpath(testlibs),
                    "com.custom.filmoip.ParserTestKt"] + ([args.fixtures] if args.fixtures else []), check=True)

    gate_html = build / "gate-test.html"
    subprocess.run([java, "-cp", str(build / "tests.jar") + os.pathsep + classpath(testlibs),
                    "com.custom.filmoip.GateTestKt", str(gate_html)]
                   + ([args.movie_fixture] if args.movie_fixture else []), check=True)
    node = shutil.which("node")
    if not node:
        raise SystemExit("Node.js 18+ is required for the CAPTCHA form regression tests.")
    subprocess.run([node, str(ROOT / "tests/GateScriptTest.js"), str(gate_html)], check=True)

    subprocess.run([sys.executable, str(ROOT / "tests/RepositoryTest.py")], check=True)

    dex = build / "dex"
    dex.mkdir(exist_ok=True)
    for stale in dex.glob("*.dex"):
        stale.unlink()
    dex_cmd = [java, "-Xmx1g", "-cp", str(args.cache / "r8-current.jar"), "com.android.tools.r8.D8",
               "--min-api", "23", "--lib", str(args.cache / "android-modern.jar"),
               "--lib", java_home, "--output", str(dex)]
    for lib in libraries:
        if lib != "android-modern.jar":
            dex_cmd += ["--classpath", str(args.cache / lib)]
    subprocess.run(dex_cmd + [str(build / "plugin.jar")], check=True)

    metadata = json.loads((ROOT / "plugin.json").read_text())
    manifest = {key: metadata[key] for key in ["name", "pluginClassName", "version"]}
    manifest["requiresResources"] = False
    archive = dist / (metadata["internalName"] + ".cs3")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as output:
        files = {"manifest.json": json.dumps(manifest).encode("utf-8")}
        files.update({p.name: p.read_bytes() for p in dex.glob("*.dex")})
        if "classes.dex" not in files:
            raise RuntimeError("D8 produced no classes.dex")
        for name, data in sorted(files.items()):
            entry = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            output.writestr(entry, data)

    if args.repo:
        base = "https://raw.githubusercontent.com/" + args.repo + "/builds"
        plugin = {k: v for k, v in metadata.items() if k != "pluginClassName"}
        plugin.update(url=base + "/" + archive.name, fileSize=archive.stat().st_size,
                      repositoryUrl="https://github.com/" + args.repo)
        write_json(dist / "plugins.json", [plugin])
        write_json(dist / "repo.json", {"name": "Filmo IP Repository",
                    "description": "Filmo-Filmerweiterung",
                    "manifestVersion": 1, "pluginLists": [base + "/plugins.json"]})
        print("Repository URL: " + base + "/repo.json")
    else:
        # Never leave stale links pointing at an earlier owner's repository.
        for filename in ["repo.json", "plugins.json"]:
            (dist / filename).unlink(missing_ok=True)
        print("Local build only. Add --repo OWNER/REPO to generate installable repository JSON.")
    write_json(build / "build-report.json", {"plugin_sha256": sha256(archive),
                "cloudstream_api_sha256": sha256(args.cache / "cloudstream.jar"),
                "kotlin_compilation": "passed", "parser_regressions": "passed", "android_dex": "passed",
                "redirect_cookie_regressions": "passed", "gate_script_regressions": "passed",
                "combined_repository_regressions": "passed",
                "android_playback": "not tested", "captcha_webview": "not tested on a device"})
    print("Built " + str(archive))


if __name__ == "__main__":
    main()
