#!/usr/bin/env python3
"""Combine independently built CS3 plugins without changing their bytes or install URLs."""
import argparse
import json
from pathlib import Path
import shutil
import zipfile
from urllib.parse import urlsplit


def assemble(inputs, output):
    output.mkdir(parents=True, exist_ok=True)
    plugins = []
    names = set()
    base = None
    packages = []
    for directory in inputs:
        for plugin in json.loads((directory / 'plugins.json').read_text()):
            name = plugin['internalName']
            if name in names:
                raise ValueError('Duplicate plugin: ' + name)
            names.add(name)
            url = urlsplit(plugin['url'])
            filename = Path(url.path).name
            if filename != name + '.cs3':
                raise ValueError('Unexpected package filename')
            current_base = plugin['url'].rsplit('/', 1)[0]
            if base is not None and current_base != base:
                raise ValueError('All plugins must use the same repository branch')
            base = current_base
            package = directory / filename
            if package.stat().st_size != plugin['fileSize']:
                raise ValueError('Package size does not match plugin manifest')
            with zipfile.ZipFile(package) as archive:
                manifest = json.loads(archive.read('manifest.json'))
                if manifest['version'] != plugin['version']:
                    raise ValueError('Compiled package version does not match plugin manifest')
                if not archive.read('classes.dex').startswith(b'dex\n'):
                    raise ValueError('Missing Android DEX')
            packages.append(package)
            plugins.append(plugin)
    if not plugins:
        raise ValueError('No plugins found')
    for package in packages:
        shutil.copyfile(package, output / package.name)
    (output / 'plugins.json').write_text(json.dumps(plugins, ensure_ascii=False, indent=2) + '\n')
    repository = {'name': 'SerienStream & Filmo IP',
                  'description': 'SerienStream für Serien und Filmo für Filme',
                  'manifestVersion': 1, 'pluginLists': [base + '/plugins.json']}
    (output / 'repo.json').write_text(json.dumps(repository, ensure_ascii=False, indent=2) + '\n')
    print('Repository plugins:', ', '.join(p['name'] + ' v' + str(p['version']) for p in plugins))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('inputs', nargs='+', type=Path)
    arguments = parser.parse_args()
    assemble(arguments.inputs, arguments.output)
