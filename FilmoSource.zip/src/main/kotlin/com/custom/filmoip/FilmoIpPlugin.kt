package com.custom.filmoip

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class FilmoIpPlugin : Plugin() {
    private var gate: ManualGate? = null
    override fun load(context: Context) {
        val resolver = ManualGate(context)
        gate = resolver
        registerMainAPI(FilmoIpProvider(resolver))
    }
    override fun beforeUnload() { gate?.dispose(); gate = null }
}
