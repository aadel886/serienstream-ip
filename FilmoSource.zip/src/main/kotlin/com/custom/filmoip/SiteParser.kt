package com.custom.filmoip

import java.net.URI
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

internal data class MovieCard(val title: String, val url: String, val poster: String?)
internal data class MovieDetails(
    val title: String, val url: String, val poster: String?, val year: Int?, val duration: Int?,
    val plot: String?, val genres: List<String>, val actors: List<String>, val trailer: String?
)
internal data class StreamButton(
    val payload: String, val provider: String, val language: String, val id: String, val quality: String
) {
    val playerLabel get() = "$provider [$language]"
    val label get() = playerLabel + if (quality.isNotBlank()) " · Website: $quality" else ""
}

internal class SiteParser(private val baseUrl: String) {
    private val base = URI(baseUrl)
    private val moviePath = Regex("^/movies/[^/]+/?$")
    private val cardSelector = "a.video-card, a.movie-poster-grid-card, a.popular-spotlight-card__link"
    fun absolute(raw: String?): String? = runCatching {
        val value = raw?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        val uri = base.resolve(value)
        if (uri.scheme !in setOf("http", "https") || uri.host == null || uri.userInfo != null) return null
        uri.toASCIIString()
    }.getOrNull()

    fun movieUrl(raw: String?): String? {
        val url = absolute(raw) ?: return null
        val uri = URI(url)
        if (!GatePage.sameOrigin(baseUrl, url) || !moviePath.matches(uri.path)) return null
        return base.resolve(uri.path.trimEnd('/')).toASCIIString()
    }

    fun card(anchor: Element): MovieCard? {
        val url = movieUrl(anchor.attr("href")) ?: return null
        val image = anchor.selectFirst("img")
        val title = image?.attr("alt").orEmpty().trim().ifBlank {
            anchor.selectFirst(".movie-poster-grid-card__title, .popular-spotlight-card__title, h3, h4")?.text().orEmpty()
        }.ifBlank { anchor.parent()?.attr("aria-label").orEmpty() }
        if (title.isBlank()) return null
        return MovieCard(title, url, absolute(image?.attr("data-src")?.ifBlank { image.attr("src") }))
    }

    fun cards(root: Element): List<MovieCard> = root.select(cardSelector).mapNotNull(::card).distinctBy { it.url }

    fun home(document: Document): List<Pair<String, List<MovieCard>>> {
        val rows = mutableListOf<Pair<String, List<MovieCard>>>()
        val highlights = document.select(".swiper-hero-layout h2 a[href]").mapNotNull(::card).distinctBy { it.url }
        if (highlights.isNotEmpty()) rows += "Highlights" to highlights
        document.select(".video-row").forEach { row ->
            val title = row.selectFirst("h3")?.ownText().orEmpty().trim()
            val items = cards(row)
            if (title.isNotBlank() && items.isNotEmpty()) rows += title to items
        }
        return rows
    }

    fun hasNext(document: Document) = document.selectFirst("a[rel=next][href]") != null

    fun details(document: Document, url: String): MovieDetails {
        val title = document.selectFirst("main h1")?.text()?.takeIf { it.isNotBlank() }
            ?: error("Filmtitel fehlt.")
        val labels = document.select("main .ft-meta-label").map { it.text().trim() }
        val year = labels.firstOrNull { Regex("(?:19|20)\\d{2}").matches(it) }?.toIntOrNull()
        val runtime = labels.firstOrNull { Regex("\\b(?:h|min)\\b").containsMatchIn(it) }.orEmpty()
        val hours = Regex("(\\d+)\\s*h\\b").find(runtime)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val minutes = Regex("(\\d+)\\s*min\\b").find(runtime)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val poster = absolute(document.selectFirst("meta[property=og:image]")?.attr("content"))
        val plot = document.selectFirst(".movie-detail-synopsis")?.text()
        val genres = document.select("main .ft-meta-label a[href*=/genres/]").map { it.text() }.distinct()
        val actors = document.select("main dl:has(h3:matchesOwn(^Darsteller$)) dd a").map { it.text() }.distinct()
        val trailer = absolute(document.selectFirst(".movie-trailer-modal__iframe[data-embed-src]")?.attr("data-embed-src"))
        return MovieDetails(title, url, poster, year, (hours * 60 + minutes).takeIf { it > 0 }, plot, genres, actors, trailer)
    }

    fun streams(document: Document): List<StreamButton> = document.select("[data-provider-chip][data-p]").mapNotNull { chip ->
        val payload = chip.attr("data-p").takeIf { it.isNotBlank() } ?: return@mapNotNull null
        val provider = chip.selectFirst(".provider-chip__name")?.text().orEmpty().ifBlank { chip.attr("aria-label") }
        val language = chip.closest(".provider-row")?.selectFirst(".provider-row__lang")?.text().orEmpty().ifBlank { "Unbekannt" }
        val id = chip.attr("data-movie-link-id").takeIf { it.isNotBlank() } ?: return@mapNotNull null
        val quality = chip.select(".provider-chip__metadata-tag").joinToString(" · ") { it.text() }
        StreamButton(payload, provider, language, "$id|$language", quality)
    }.distinctBy { it.id }
}
