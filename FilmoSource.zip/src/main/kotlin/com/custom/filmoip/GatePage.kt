package com.custom.filmoip

import java.net.URI
import org.jsoup.nodes.Document

internal data class MintRequest(val stream: StreamButton, val endpoint: String, val csrf: String)
internal data class GateRequest(val stream: StreamButton, val action: String, val fields: List<Pair<String, String>>, val siteKey: String)

/** Compact pages at Filmo's real origin. Stream tickets follow the website's ordinary API. */
internal object GatePage {
    fun sameOrigin(first: String, second: String): Boolean = runCatching {
        val a = URI(first); val b = URI(second)
        fun port(u: URI) = if (u.port >= 0) u.port else if (u.scheme == "https") 443 else 80
        a.scheme in setOf("http", "https") && a.scheme == b.scheme &&
            a.host != null && a.host.equals(b.host, true) && port(a) == port(b)
    }.getOrDefault(false)
    fun externalTarget(site: String, target: String): Boolean = runCatching {
        val uri = URI(target); val host = uri.host?.lowercase() ?: return false
        uri.scheme in setOf("http", "https") && uri.userInfo == null && !sameOrigin(site, target) &&
            host != "challenges.cloudflare.com" && !host.endsWith(".cloudflare.com")
    }.getOrDefault(false)
    fun isTicket(site: String, url: String): Boolean = runCatching {
        sameOrigin(site, url) && Regex("^/n/[A-Za-z0-9_-]{1,512}$").matches(URI(url).path)
    }.getOrDefault(false)

    // Byse uses Filmo's "open external video" page instead of an HTTP redirect.
    fun externalLink(document: Document, pageUrl: String): String? {
        val anchor = document.select("a.open[href][target=_blank]").singleOrNull() ?: return null
        val url = runCatching { URI(pageUrl).resolve(anchor.attr("href")).toASCIIString() }.getOrNull() ?: return null
        return url.takeIf { externalTarget(pageUrl, it) }
    }

    fun prepare(document: Document, movieUrl: String, selected: StreamButton): MintRequest {
        // A link ID can occur in more than one language row; the parser includes language in its identity.
        val fresh = SiteParser(movieUrl).streams(document).firstOrNull { it.id == selected.id }
            ?: error("Die ausgewählte Quelle ist nicht mehr vorhanden.")
        val config = document.select("script").joinToString("\n") { it.data() }
        val endpoint = Regex(""""openMint"\s*:\s*"([^"]+)"""").find(config)?.groupValues?.get(1)
            ?.replace("\\/", "/") ?: error("Die Website liefert keine Freigabeadresse.")
        require(sameOrigin(movieUrl, endpoint) && URI(endpoint).path == "/n" && URI(endpoint).userInfo == null) {
            "Unerwartete Freigabeadresse."
        }
        val csrf = document.selectFirst("meta[name=csrf-token]")?.attr("content").orEmpty()
        require(csrf.isNotBlank()) { "Website-Sitzung fehlt." }
        return MintRequest(fresh, endpoint, csrf)
    }

    private fun html(value: String) = value.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")
    private fun page(body: String, script: String, external: String = "") = """<!doctype html><html lang="de"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{margin:0;padding:16px;background:#16181e;color:#fff;font:18px sans-serif;text-align:center}
button{padding:12px 24px;border:2px solid #aaa;border-radius:8px;background:#205b91;color:#fff;font:inherit}
button:focus{outline:4px solid #fff}button:disabled{opacity:.55}
#challenge{display:flex;justify-content:center;min-height:70px;margin:12px 0}
#status{min-height:2.5em;font-size:16px}p{margin:8px 0}</style></head><body>
$body<script>$script</script>$external</body></html>"""

    fun renderMint(request: MintRequest): String = page("""
<p>Filmo · ${html(request.stream.playerLabel)}</p>
<p id="status" role="status">Quelle wird vorbereitet …</p>
<input id="endpoint" type="hidden" value="${html(request.endpoint)}">
<input id="csrf" type="hidden" value="${html(request.csrf)}">
<input id="payload" type="hidden" value="${html(request.stream.payload)}">
""", """
(function(){
  var status=document.getElementById('status'), endpoint=document.getElementById('endpoint').value;
  function fail(){status.textContent='Diese Quelle konnte nicht geöffnet werden. Bitte „Erneut versuchen“ oder eine andere Quelle wählen.';}
  var request=new XMLHttpRequest();
  request.open('POST',endpoint,true);request.timeout=25000;request.withCredentials=true;
  request.setRequestHeader('Content-Type','application/json');
  request.setRequestHeader('Accept','application/json');
  request.setRequestHeader('X-Requested-With','XMLHttpRequest');
  request.setRequestHeader('X-CSRF-TOKEN',document.getElementById('csrf').value);
  request.onload=function(){
    if(request.status<200||request.status>=300){fail();return;}
    try{
      var data=JSON.parse(request.responseText);
      if(!data||typeof data.x!=='string'||!/^[A-Za-z0-9_-]{1,512}$/.test(data.x)){fail();return;}
      status.textContent='Stream wird an Cloudstream übergeben …';
      window.location.assign(endpoint.replace(/\/+$/,'')+'/'+encodeURIComponent(data.x));
    }catch(error){fail();}
  };
  request.onerror=fail;request.ontimeout=fail;
  request.send(JSON.stringify({p:document.getElementById('payload').value}));
})();
""")

    /** Optional normal Turnstile form. No automatic CAPTCHA solving or full video website. */
    fun prepareChallenge(document: Document, pageUrl: String, stream: StreamButton): GateRequest {
        val form = document.selectFirst("form:has([data-sitekey])")
            ?: error("Die Website liefert keine unterstützte Freigabe.")
        require(form.attr("method").equals("post", true))
        val action = URI(pageUrl).resolve(form.attr("action").ifBlank { pageUrl }).toASCIIString()
        require(sameOrigin(pageUrl, action) && (URI(action).path == "/n" || isTicket(pageUrl, action)))
        val key = form.selectFirst("[data-sitekey]")?.attr("data-sitekey").orEmpty()
        require(key.isNotBlank())
        val fields = form.select("input[type=hidden][name]").map { it.attr("name") to it.attr("value") }
            .filterNot { it.first == "cf-turnstile-response" }
        return GateRequest(stream, action, fields, key)
    }
    fun renderChallenge(request: GateRequest): String = page("""
<p>Freigabe durch Filmo</p><p>${html(request.stream.playerLabel)}</p>
<form id="gate" method="post" action="${html(request.action)}" target="_self">
${request.fields.joinToString("\n") { (name, value) -> "<input type=\"hidden\" name=\"${html(name)}\" value=\"${html(value)}\">" }}
<div id="challenge" data-key="${html(request.siteKey)}"></div>
<p id="status" role="status">Bitte das CAPTCHA bestätigen. Danach geht es automatisch weiter.</p>
<button id="next" type="submit" disabled>Weiter zu Cloudstream</button></form>
""", """
(function(){
 var form=document.getElementById('gate'),next=document.getElementById('next'),status=document.getElementById('status');
 var ready=false,sent=false;
 function submit(){if(!ready||sent)return;sent=true;next.disabled=true;status.textContent='Freigabe wird geprüft …';form.submit();}
 form.addEventListener('submit',function(e){e.preventDefault();submit();});
 window.onGateReady=function(){window.turnstile.render('#challenge',{
  sitekey:document.getElementById('challenge').getAttribute('data-key'),theme:'dark',
  callback:function(){if(sent)return;ready=true;next.disabled=false;submit();},
  'expired-callback':function(){ready=false;sent=false;next.disabled=true;status.textContent='Freigabe abgelaufen. Bitte erneut bestätigen.';},
  'error-callback':function(){ready=false;next.disabled=true;status.textContent='CAPTCHA konnte nicht geladen werden. Bitte „Erneut versuchen“ wählen.';}
 });};
})();
""", """<script src="https://challenges.cloudflare.com/turnstile/v0/api.js?onload=onGateReady&amp;render=explicit" async defer></script>""")
}
