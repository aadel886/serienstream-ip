package com.custom.filmoip

import android.app.Activity
import android.app.AlertDialog
import android.app.Application
import android.app.Dialog
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.lagradost.cloudstream3.ErrorLoadingException
import java.io.ByteArrayInputStream
import java.lang.ref.WeakReference
import java.net.URI
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

internal data class ResolvedStream(val url: String, val stream: StreamButton)

/** Native source picker, followed only when necessary by the website's manual CAPTCHA. */
class ManualGate(context: Context) : Application.ActivityLifecycleCallbacks {
    private val app = context.applicationContext as? Application
    private val main = Handler(Looper.getMainLooper())
    private var activity = WeakReference(findActivity(context))
    private var activeDialog: Dialog? = null
    private val mutex = Mutex()

    init { app?.registerActivityLifecycleCallbacks(this) }

    private fun findActivity(context: Context): Activity? {
        var current = context
        while (current is ContextWrapper) {
            if (current is Activity) return current
            val parent = current.baseContext
            if (parent === current) break
            current = parent
        }
        return current as? Activity
    }

    private fun host(): Activity = activity.get()?.takeUnless { it.isFinishing }
        ?: throw ErrorLoadingException("Cloudstream bitte neu öffnen; die Freigabe benötigt ein aktives App-Fenster.")

    internal suspend fun resolve(movieUrl: String, sources: List<StreamButton>): ResolvedStream? = mutex.withLock {
        val ordered = sources.sortedBy { if (it.language.equals("Deutsch", true)) 0 else 1 }
        val selected = if (ordered.size == 1) ordered.single() else choose(ordered)
        selected?.let { open(movieUrl, it) }
    }

    private suspend fun choose(sources: List<StreamButton>): StreamButton? = suspendCancellableCoroutine { continuation ->
        main.post {
            if (!continuation.isActive) return@post
            try {
                val dialog = AlertDialog.Builder(host())
                    .setTitle("Quelle und Sprache auswählen")
                    .setItems(sources.map { it.label }.toTypedArray()) { _, index ->
                        if (continuation.isActive) continuation.resume(sources[index])
                    }
                    .setNegativeButton("Abbrechen") { _, _ -> }
                    .create()
                activeDialog = dialog
                dialog.setOnDismissListener {
                    if (activeDialog === dialog) activeDialog = null
                    if (continuation.isActive) continuation.resume(null)
                }
                continuation.invokeOnCancellation { main.post { dialog.dismiss() } }
                dialog.show()
            } catch (_: Exception) {
                if (continuation.isActive) continuation.resumeWithException(
                    ErrorLoadingException("Die Quellenauswahl konnte nicht geöffnet werden. Cloudstream bitte neu starten.")
                )
            }
        }
    }

    private suspend fun open(movieUrl: String, selected: StreamButton): ResolvedStream? =
        suspendCancellableCoroutine { continuation ->
            main.post {
                if (!continuation.isActive) return@post
                var cleanup: (() -> Unit)? = null
                try {
                    val host = host()
                    val done = AtomicBoolean(false)
                    val generation = AtomicInteger(0)
                    val dialog = Dialog(host)
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                    val web = WebView(host)
                    val cookieManager = CookieManager.getInstance()
                    val userAgent = web.settings.userAgentString
                    var timeout: Runnable? = null
                    var readyUrl: String? = null
                    activeDialog = dialog
                    fun dp(value: Int) = (value * host.resources.displayMetrics.density + 0.5f).toInt()
                    fun clearTimeout() { timeout?.let(main::removeCallbacks); timeout = null }
                    fun finish(url: String?) {
                        if (!done.compareAndSet(false, true)) return
                        main.post {
                            clearTimeout()
                            dialog.setOnDismissListener(null)
                            web.stopLoading()
                            dialog.dismiss()
                            (web.parent as? ViewGroup)?.removeView(web)
                            web.destroy()
                            if (activeDialog === dialog) activeDialog = null
                            if (continuation.isActive) continuation.resume(url?.let { ResolvedStream(it, selected) })
                        }
                    }
                    cleanup = { finish(null) }
                    continuation.invokeOnCancellation { finish(null) }
                    dialog.setOnDismissListener { finish(null) }

                    val layout = LinearLayout(host).apply {
                        orientation = LinearLayout.VERTICAL
                        setBackgroundColor(Color.rgb(22, 24, 30))
                        setPadding(dp(16), dp(12), dp(16), dp(12))
                    }
                    val instruction = TextView(host).apply {
                        setTextColor(Color.WHITE)
                        textSize = 17f
                        setPadding(dp(4), dp(4), dp(4), dp(10))
                    }
                    val toolbar = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL }
                    web.id = View.generateViewId()
                    web.isFocusable = true
                    web.isFocusableInTouchMode = true
                    lateinit var retry: Button
                    fun failure(message: String, attempt: Int) {
                        main.post {
                            if (done.get() || attempt != generation.get()) return@post
                            generation.incrementAndGet() // Ignore responses from this abandoned request.
                            clearTimeout()
                            web.stopLoading()
                            web.visibility = View.INVISIBLE
                            instruction.text = message
                            retry.requestFocus()
                        }
                    }
                    fun armTimeout(attempt: Int) {
                        clearTimeout()
                        timeout = Runnable { failure("Die Website antwortet nicht. Bitte erneut versuchen oder abbrechen.", attempt) }
                            .also { main.postDelayed(it, 60000) }
                    }
                    fun load() {
                        if (done.get()) return
                        val attempt = generation.incrementAndGet()
                        readyUrl = null
                        instruction.text = "${selected.label}\nFreigabe wird geladen …"
                        web.visibility = View.INVISIBLE
                        armTimeout(attempt)
                        web.loadUrl(movieUrl)
                    }
                    fun control(label: String, action: () -> Unit) = Button(host).apply {
                        id = View.generateViewId()
                        text = label
                        setAllCaps(false)
                        isFocusable = true
                        textSize = 14f
                        minWidth = 0
                        minimumWidth = 0
                        setTextColor(Color.WHITE)
                        fun shape(color: Int, stroke: Int) = GradientDrawable().apply {
                            setColor(color); setCornerRadius(dp(7).toFloat()); setStroke(dp(2), stroke)
                        }
                        background = StateListDrawable().apply {
                            addState(intArrayOf(android.R.attr.state_focused), shape(Color.rgb(24, 93, 150), Color.WHITE))
                            addState(intArrayOf(), shape(Color.rgb(45, 49, 59), Color.GRAY))
                        }
                        setOnClickListener { action() }
                    }
                    val focus = control("Zum Formular") { web.requestFocus() }
                    retry = control("Erneut versuchen") { load() }
                    val close = control("Abbrechen") { finish(null) }
                    val controls = listOf(focus, retry, close)
                    controls.forEachIndexed { index, button ->
                        button.nextFocusLeftId = controls[(index + controls.size - 1) % controls.size].id
                        button.nextFocusRightId = controls[(index + 1) % controls.size].id
                        button.nextFocusDownId = web.id
                        toolbar.addView(button, LinearLayout.LayoutParams(0, dp(56), 1f).apply {
                            setMargins(dp(3), dp(4), dp(3), dp(8))
                        })
                    }
                    web.nextFocusUpId = focus.id
                    dialog.setOnKeyListener { _, code, event ->
                        if (code == KeyEvent.KEYCODE_MENU) {
                            if (event.action == KeyEvent.ACTION_UP) focus.requestFocus()
                            true
                        } else false
                    }
                    layout.addView(instruction)
                    layout.addView(toolbar)
                    layout.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
                    web.settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        allowFileAccess = false
                        allowContentAccess = false
                        javaScriptCanOpenWindowsAutomatically = false
                        setSupportMultipleWindows(false)
                        mediaPlaybackRequiresUserGesture = true
                        cacheMode = WebSettings.LOAD_NO_CACHE
                    }
                    cookieManager.setAcceptThirdPartyCookies(web, true)
                    web.setWebChromeClient(WebChromeClient())
                    val session = GateSession(movieUrl, userAgent,
                        { cookieManager.getCookie(it) }, { url, value -> cookieManager.setCookie(url, value) })
                    fun emptyResponse() = WebResourceResponse("text/html", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                    web.setWebViewClient(object : WebViewClient() {
                        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                            val requestUrl = request.url.toString()
                            if (!request.isForMainFrame || request.method != "GET" ||
                                (requestUrl != movieUrl && !GatePage.isTicket(movieUrl, requestUrl))) return null
                            val attempt = generation.get()
                            var step = "Filmseite"
                            return try {
                                val response = session.get(requestUrl)
                                if (done.get() || attempt != generation.get()) return emptyResponse()
                                if (response.target != null) {
                                    finish(response.target)
                                    emptyResponse()
                                } else {
                                    val page = response.response?.parse() ?: error("Website-Antwort fehlt.")
                                    val isMovie = requestUrl == movieUrl
                                    if (!isMovie) {
                                        val target = GatePage.externalLink(page, response.response.url().toString())
                                        if (target != null) {
                                            finish(target)
                                            return emptyResponse()
                                        }
                                    }
                                    step = if (isMovie) "Quellenauswahl" else "CAPTCHA-Formular"
                                    val html = if (isMovie) GatePage.renderMint(GatePage.prepare(page, movieUrl, selected))
                                        else GatePage.renderChallenge(GatePage.prepareChallenge(page, response.response.url().toString(), selected))
                                    main.post {
                                        if (!done.get() && attempt == generation.get()) {
                                            readyUrl = requestUrl
                                            instruction.text = if (isMovie) "${selected.label}\nQuelle wird vorbereitet …"
                                                else "${selected.label}\nCAPTCHA bestätigen. Danach übernimmt Cloudstream automatisch."
                                            web.visibility = View.VISIBLE
                                            clearTimeout()
                                        }
                                    }
                                    WebResourceResponse("text/html", "UTF-8", ByteArrayInputStream(html.toByteArray(Charsets.UTF_8)))
                                }
                            } catch (_: Exception) {
                                failure("$step konnte nicht geladen werden. Bitte erneut versuchen; bei wiederholtem Fehler eine andere Quelle wählen.", attempt)
                                emptyResponse()
                            }
                        }

                        @Suppress("DEPRECATION")
                        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                            // No host-name allowlist: VOE uses changing mirror domains. onPageStarted is main-frame only.
                            if (url == "about:blank" || url == "about:srcdoc") return false
                            return runCatching { URI(url).scheme !in setOf("http", "https") }.getOrDefault(true)
                        }

                        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                            readyUrl = null
                            if (GatePage.externalTarget(movieUrl, url)) {
                                view.stopLoading()
                                finish(url)
                            } else if (url != movieUrl && GatePage.sameOrigin(movieUrl, url)) {
                                web.visibility = View.INVISIBLE
                                instruction.text = "Freigabe wird geprüft; Stream wird an Cloudstream übergeben …"
                                armTimeout(generation.get())
                            }
                        }

                        override fun onPageFinished(view: WebView, url: String) {
                            if (done.get()) return
                            if (GatePage.externalTarget(movieUrl, url)) {
                                finish(url)
                            } else if (readyUrl == url) {
                                clearTimeout()
                            } else if (url != movieUrl && GatePage.sameOrigin(movieUrl, url)) {
                                failure("Die Website hat die Freigabe nicht bestätigt. Bitte erneut versuchen. Bei einer abgelaufenen Sitzung wird ein neues CAPTCHA geladen.", generation.get())
                            }
                        }

                        @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
                        override fun onReceivedError(view: WebView, code: Int, description: String, failingUrl: String) {
                            if (failingUrl == movieUrl || failingUrl == view.url) {
                                failure("Verbindungsfehler. Bitte erneut versuchen oder abbrechen.", generation.get())
                            }
                        }
                        // Default TLS validation stays enabled. No JS bridge or access to device files is exposed.
                    })
                    dialog.setContentView(layout)
                    dialog.show()
                    val metrics = host.resources.displayMetrics
                    dialog.window?.setLayout(minOf(dp(720), (metrics.widthPixels * .92).toInt()),
                        minOf(dp(500), (metrics.heightPixels * .92).toInt()))
                    focus.requestFocus()
                    load()
                } catch (_: Exception) {
                    if (continuation.isActive) continuation.resumeWithException(
                        ErrorLoadingException("Das Freigabefenster konnte nicht geöffnet werden. Cloudstream bitte neu starten.")
                    )
                    cleanup?.invoke()
                }
            }
        }

    fun dispose() {
        app?.unregisterActivityLifecycleCallbacks(this)
        main.post { activeDialog?.dismiss(); activeDialog = null }
    }
    override fun onActivityResumed(value: Activity) { activity = WeakReference(value) }
    override fun onActivityCreated(value: Activity, state: Bundle?) { activity = WeakReference(value) }
    override fun onActivityDestroyed(value: Activity) { if (activity.get() === value) activity.clear() }
    override fun onActivityStarted(value: Activity) {}
    override fun onActivityPaused(value: Activity) {}
    override fun onActivityStopped(value: Activity) {}
    override fun onActivitySaveInstanceState(value: Activity, state: Bundle) {}
}
