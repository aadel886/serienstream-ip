package com.custom.filmoip

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.LoadResponse.Companion.addActors
import com.lagradost.cloudstream3.LoadResponse.Companion.addTrailer
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.extractorApis
import com.lagradost.cloudstream3.utils.loadExtractor
import com.lagradost.cloudstream3.utils.newExtractorLink
import java.net.URLEncoder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document

class FilmoIpProvider(private val gate: ManualGate) : MainAPI() {
    override var name = "Filmo IP"
    override var mainUrl = "http://45.10.243.23"
    override var lang = "de"
    override val supportedTypes = setOf(TvType.Movie)
    override val hasMainPage = true
    override val mainPage = mainPageOf("/" to "Filmo entdecken", "/movies" to "Alle Filme", "/popular" to "Beliebt")
    private val parser get() = SiteParser(mainUrl)

    private suspend fun document(url: String): Document = withContext(Dispatchers.IO) {
        Jsoup.connect(url).userAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/130.0.0.0 Mobile Safari/537.36")
            .timeout(25000).maxBodySize(4 * 1024 * 1024).get()
    }
    private fun MovieCard.toSearch(): SearchResponse = newMovieSearchResponse(title, url, TvType.Movie) { posterUrl = poster }

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val path = request.data
        val url = mainUrl.trimEnd('/') + path + if (path == "/movies") "?page=$page" else ""
        val doc = document(url)
        val rows = if (path == "/movies") listOf("Alle Filme" to parser.cards(doc.selectFirst("main") ?: doc)) else parser.home(doc)
        if (rows.all { it.second.isEmpty() }) throw ErrorLoadingException("Keine Filme gefunden. Die Website hat sich möglicherweise geändert.")
        return newHomePageResponse(rows.map { (title, items) -> HomePageList(title, items.map { it.toSearch() }) },
            hasNext = path == "/movies" && parser.hasNext(doc))
    }

    override suspend fun search(query: String): List<SearchResponse> {
        if (query.isBlank()) return emptyList()
        val doc = document("$mainUrl/search?q=${URLEncoder.encode(query.trim(), "UTF-8")}")
        return parser.cards(doc.selectFirst("main") ?: doc).map { it.toSearch() }
    }

    override suspend fun load(url: String): LoadResponse {
        val canonical = parser.movieUrl(url) ?: throw ErrorLoadingException("Ungültige Filmadresse.")
        val doc = document(canonical)
        val info = parser.details(doc, canonical)
        return newMovieLoadResponse(info.title, canonical, TvType.Movie, canonical) {
            posterUrl = info.poster
            year = info.year
            duration = info.duration
            plot = info.plot
            tags = info.genres
            addActors(info.actors)
            addTrailer(info.trailer)
            recommendations = parser.cards(doc).filter { it.url != canonical }.map { it.toSearch() }
        }
    }

    override suspend fun loadLinks(data: String, isCasting: Boolean, subtitleCallback: (SubtitleFile) -> Unit,
                                   callback: (ExtractorLink) -> Unit): Boolean {
        val url = parser.movieUrl(data) ?: return false
        val sources = parser.streams(document(url))
        if (sources.isEmpty()) throw ErrorLoadingException("Für diesen Film sind derzeit keine Quellen verfügbar.")
        val resolved = gate.resolve(url, sources) ?: return false
        val links = mutableListOf<ExtractorLink>()
        val collect: (ExtractorLink) -> Unit = { links.add(it) }
        val extractor = extractorApis.firstOrNull { it.name.equals(resolved.stream.provider, true) }
        try { extractor?.getUrl(resolved.url, url, subtitleCallback, collect) }
        catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { /* Fall back to the URL-based resolver below. */ }
        if (links.isEmpty()) {
            try { loadExtractor(resolved.url, url, subtitleCallback, collect) }
            catch (cancel: CancellationException) { throw cancel }
            catch (_: Exception) { /* Report a player error instead of opening a browser video. */ }
        }
        if (links.isEmpty()) throw ErrorLoadingException(
            "${resolved.stream.provider} liefert keinen abspielbaren Stream. Cloudstream aktualisieren oder eine andere Quelle wählen."
        )
        for (link in links.distinctBy { Triple(it.url, it.quality, it.type) }) {
            callback(newExtractorLink(resolved.stream.provider, "${resolved.stream.playerLabel} · ${link.name}", link.url, link.type) {
                referer = link.referer
                quality = link.quality // Preserve every resolution returned by the extractor; no 720p cap.
                headers = link.headers
                extractorData = link.extractorData
            })
        }
        return true
    }
}
