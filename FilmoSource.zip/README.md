# Filmo IP für Cloudstream — Version 1

Filmerweiterung für **http://45.10.243.23/**, im gemeinsamen Repository mit
SerienStream IP. Die Film-Erweiterung wird separat installiert.

Repository-Adresse:
https://raw.githubusercontent.com/aadel886/serienstream-ip/builds/repo.json

## Auf dem Fire TV verwenden

1. In Cloudstream unter **Einstellungen → Erweiterungen** das vorhandene
   Repository aktualisieren und **Filmo IP** installieren.
2. Auf der Startseite **Filmo IP** als Quelle auswählen.
3. Film suchen oder durch die Kategorien bzw. **Alle Filme** blättern.
4. Film öffnen und auf Abspielen drücken. Hoster und Sprache auswählen,
   beispielsweise **VOE [Deutsch]**.
5. Die Erweiterung übergibt die Quelle an Cloudstreams Player.

Die aktuelle Cloudstream-Vorabversion und Android API 23+ werden benötigt.
Der Fire TV Stick 4K Plus erfüllt die Android-Voraussetzung.
Die Fernbedienung bedient Quellenauswahl, Wiederholen und Abbrechen.
Die Menütaste führt im kleinen Freigabefenster zurück zur Bedienleiste.

## Funktionen

- Kategorien und Highlights sowie eine Filmübersicht mit weiteren Seiten.
- Filmsuche, Vorschaubilder, Beschreibung, Erscheinungsjahr, Laufzeit,
  Genres, Darsteller und Trailer, soweit die Website sie anbietet.
- Hoster- und Sprachauswahl in einem nativen Dialog.
- Anzeige der Qualitätskennzeichnung der Website schon bei der Quellenauswahl.
- Direkte Übergabe von VOE und Byse an die vorhandenen Cloudstream-Extractoren.
- Alle vom Extractor gelieferten Auflösungen; kein künstliches 720p-Limit.
- Automatische Updates über das bestehende Repository.

Favoriten, Verlauf, Wiedergabefortschritt und Player-Steuerung stellt Cloudstream
bereit. Manche Quellen haben mehrere Tonspuren; diese gegebenenfalls im Player
unter Audio auswählen. Die Website-Sprache allein garantiert keine voreingestellte
Tonspur im Video.

## Freigabe und Qualität

Filmo verwendet einen eigenen Freigabeweg: Mit aktuellen Website-Cookies,
CSRF-Token und dem gewählten Quelleneintrag wird die reguläre Adresse `/n`
aufgerufen. Die resultierende Hoster-Adresse wird an Cloudstream übergeben.
Byse liefert derzeit zunächst eine Filmo-Zwischenseite mit einem externen Link;
auch dieser wird aufgelöst, ohne den Browser-Player zu öffnen.

Bei den geprüften Quellen wurde kein CAPTCHA verlangt. Für eine gewöhnliche
Turnstile-Formularfreigabe ist ein kompaktes manuelles Fenster vorbereitet.
Unbekannte Freigabearten zeigen einen Fehler. CAPTCHAs werden nicht automatisch
gelöst; ein echtes CAPTCHA dieser Filmseite wurde nicht getestet.

**„Website: 720p“ ist die Angabe von Filmo**, keine Begrenzung des Plugins.
Beispielsweise waren die geprüften Interstellar-Quellen am 2. November 2026
mit 720p markiert. Cloudstreams Player erhält die tatsächlich vom Extractor
gefundenen Varianten. 1080p und 4K sind nur möglich, wenn der Hoster entsprechende
Streams bereitstellt. Hochskalieren auf dem Fernseher ersetzt keine höher
aufgelöste Quelle.

## Prüfstand

Kotlin-Build, Android-DEX, Parser-Tests, lokale HTTP-Tests für Cookies und
Weiterleitungen sowie JavaScript-Tests für die reguläre Freigabe bestanden.
Die Tests prüfen auch die getrennte Sprachauswahl bei identischen Link-IDs,
1080p-/2160p-Qualitätsangaben, fehlerhafte Antworten und den Erhalt der
SerienStream-Installationsdatei beim Zusammenführen des Repositorys.

Aktuelle Website-Seiten wurden geprüft: 9 Startseitenbereiche,
7 Bereiche unter Beliebt, 6 Treffer zur Testsuche, 42 Filmkarten und
4 Hoster-/Sprachkombinationen auf der Test-Filmseite. Die reguläre Freigabe
für VOE und die externe Byse-Verlinkung wurden überprüft.

**Vollständige Wiedergabe auf einem echten Android-/Fire-TV-Gerät steht noch aus.**
Bei einem Fehler helfen Filmname, Hoster, Sprache, Cloudstream-Version und der
exakte Fehlertext. Keine Cookies, Passwörter oder Freigabe-Tokens weitergeben.

## Selbst bauen

Voraussetzungen: Python 3.10+, Java 17+, Node.js 18+ und Internetzugang.
Das Quellarchiv **FilmoSource.zip** entpacken, dann:

```bash
python tools/build.py --repo aadel886/serienstream-ip
```

`dist/FilmoIP.cs3` ist das kompilierte Plugin. Lokale Website-Dateien können
zusätzlich mit `--fixtures VERZEICHNIS` und `--movie-fixture DATEI` geprüft werden.
Sie gehören nicht ins Quellarchiv. Abhängigkeiten sind in `dependencies.json`
mit SHA-256-Prüfsummen festgelegt.

Der gemeinsame GitHub-Workflow baut beide Quellarchive und führt die geprüften
Ergebnisse mit `tools/assemble_repo.py` in einer gemeinsamen Pluginliste zusammen.
Die SerienStream-Erweiterung hat eine eigene Paketkennung und bleibt Version 3.
Der im Film-Quellarchiv enthaltene Workflow ist für einen separaten Fork mit
entpacktem Quellcode gedacht.

Technische Grundlage: [Cloudstream](https://github.com/recloudstream/cloudstream),
dessen VOE-/Byse-Extractoren und die öffentlich ausgelieferten Filmo-Seiten.
Website-Inhalte, Sitzungsdaten und Videos werden nicht im Plugin ausgeliefert.
