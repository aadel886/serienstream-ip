package com.custom.filmoip

import java.io.File
import org.jsoup.Jsoup

fun main(args: Array<String>) {
    val parser = SiteParser("http://45.10.243.23")
    val document = Jsoup.parse("""
      <main><div class="video-row"><h3>Neue Filme <a>Mehr anzeigen</a></h3>
        <a class="video-card" href="/movies/demo"><img alt="Demo" data-src="/cover.jpg"></a>
        <a class="video-card" href="/movies/demo"><img alt="Demo"></a></div>
        <a class="popular-spotlight-card__link" href="/movies/second"><img alt=""><h4 class="popular-spotlight-card__title">Zweiter Film</h4></a>
        <a class="movie-poster-grid-card" href="/movies/third"><img src="/third.jpg" alt="Dritter Film"></a>
        <a rel="next" href="/movies?page=2">Weiter</a>
        <h1>Demo</h1><p class="movie-detail-synopsis">Beschreibung</p>
        <span class="ft-meta-label">2014</span><span class="ft-meta-label">2 h 49 min</span>
        <span class="ft-meta-label"><a href="/genres/drama">Drama</a></span>
        <dl><dt><h3>Darsteller</h3></dt><dd><a>Person A</a></dd></dl>
        <div class="provider-row"><span class="provider-row__lang">English</span>
          <div data-provider-chip data-movie-link-id="1" data-p="en"><span class="provider-chip__name">VOE</span><span class="provider-chip__metadata-tag">1080p</span></div></div>
        <div class="provider-row"><span class="provider-row__lang">Deutsch</span>
          <div data-provider-chip data-movie-link-id="1" data-p="de"><span class="provider-chip__name">VOE</span><span class="provider-chip__metadata-tag">2160p</span></div></div>
      </main>
    """)
    check(parser.home(document).single().first == "Neue Filme")
    check(parser.home(document).single().second.single().poster == "http://45.10.243.23/cover.jpg")
    check(parser.cards(document).size == 3)
    check(parser.cards(document)[1].title == "Zweiter Film")
    check(parser.hasNext(document))
    check(parser.movieUrl("/movies/demo?x=1#fragment") == "http://45.10.243.23/movies/demo")
    check(parser.movieUrl("https://other.example/movies/demo") == null)
    check(parser.movieUrl("/movies") == null)
    check(parser.absolute("javascript:alert(1)") == null)
    val info = parser.details(document, "http://45.10.243.23/movies/demo")
    check(info.title == "Demo" && info.year == 2014 && info.duration == 169)
    check(info.genres == listOf("Drama") && info.actors == listOf("Person A"))
    val sources = parser.streams(document)
    check(sources.size == 2 && sources.map { it.id }.distinct().size == 2)
    check(sources.last().language == "Deutsch" && sources.last().quality == "2160p")
    check(sources.first().quality == "1080p") // Website labels are preserved without a quality cap.
    if (args.isNotEmpty()) {
        val root = File(args[0])
        fun page(name: String) = Jsoup.parse(File(root, "$name.html"), "UTF-8")
        val home = parser.home(page("home"));val popular = parser.home(page("popular"))
        val search = parser.cards(page("search"));val movies = parser.cards(page("movies"))
        val movie = page("movie");val detail = parser.details(movie, "http://45.10.243.23/movies/interstellar")
        check(home.size >= 8 && popular.isNotEmpty() && movies.size >= 20)
        check(search.any { it.title == "Interstellar" })
        check(parser.hasNext(page("movies")))
        check(detail.year == 2014 && detail.duration == 169 && detail.actors.isNotEmpty())
        val streams = parser.streams(movie)
        check(streams.size == 4 && streams.any { it.language == "Deutsch" } && streams.any { it.language == "English" })
        val intermediate = File(root, "byse-gate.html")
        if (intermediate.exists()) {
            check(GatePage.externalLink(Jsoup.parse(intermediate, "UTF-8"), "http://45.10.243.23/n/ticket") != null)
            println("Live Byse intermediate page: external player address recovered without opening a browser player.")
        }
        println("Live HTML: ${home.size} home rows, ${popular.size} popular rows, ${search.size} search results, ${movies.size} movies, ${streams.size} hoster/language choices.")
    }
    println("Movie parser regressions: PASS (cards, metadata, search, pagination, language identity, 1080p/2160p labels).")
}
