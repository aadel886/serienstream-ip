package com.custom.filmoip

import com.sun.net.httpserver.HttpServer
import java.io.File
import java.net.InetSocketAddress
import org.jsoup.Jsoup

fun main(args: Array<String>) {
    val movieUrl = "http://45.10.243.23/movies/demo"
    val document = Jsoup.parse("""
      <meta name="csrf-token" content="fresh-session">
      <div class="provider-row"><span class="provider-row__lang">English</span>
      <div data-provider-chip data-movie-link-id="1" data-p="EN-new"><span class="provider-chip__name">VOE</span></div></div>
      <div class="provider-row"><span class="provider-row__lang">Deutsch</span>
      <div data-provider-chip data-movie-link-id="1" data-p="DE-new"><span class="provider-chip__name">VOE</span></div></div>
      <script>window.filmoLibrary={"urls":{"openMint":"http:\/\/45.10.243.23\/n"}};</script>
    """)
    val selected = StreamButton("old-payload", "VOE", "Deutsch", "1|Deutsch", "720p")
    val prepared = GatePage.prepare(document, movieUrl, selected)
    check(prepared.stream.payload == "DE-new" && prepared.csrf == "fresh-session")
    check(prepared.endpoint == "http://45.10.243.23/n")
    val mint = GatePage.renderMint(prepared)
    check(Jsoup.parse(mint).select("iframe,video,script[src]").isEmpty())
    File(args[0] + ".mint.html").writeText(mint)
    check(GatePage.isTicket(movieUrl, "http://45.10.243.23/n/abc-123_X"))
    check(!GatePage.isTicket(movieUrl, "http://elsewhere.example/n/abc"))
    check(!GatePage.isTicket(movieUrl, "http://45.10.243.23/n/../../login"))
    check(GatePage.externalTarget(movieUrl, "https://new-voe-domain.example/e/abc"))
    check(!GatePage.externalTarget(movieUrl, "https://challenges.cloudflare.com/"))
    check(!GatePage.externalTarget(movieUrl, "javascript:alert(1)"))
    val external = Jsoup.parse("""<a class="open" target="_blank" href="https://bysezejataos.com/d/example">Video öffnen</a>""")
    check(GatePage.externalLink(external, "http://45.10.243.23/n/ticket") == "https://bysezejataos.com/d/example")
    external.selectFirst("a")!!.attr("href", "javascript:alert(1)")
    check(GatePage.externalLink(external, "http://45.10.243.23/n/ticket") == null)
    check(runCatching { GatePage.prepare(document, movieUrl, selected.copy(id = "missing")) }.isFailure)
    val changed = document.clone();changed.selectFirst("script")!!.html("""window.filmoLibrary={"urls":{"openMint":"https://other.example/n"}};""")
    check(runCatching { GatePage.prepare(changed, movieUrl, selected) }.isFailure)
    val escaped = GatePage.renderMint(prepared.copy(stream = prepared.stream.copy(payload = "</script>\"&<")))
    check(Jsoup.parse(escaped).selectFirst("#payload")!!.attr("value") == "</script>\"&<")
    check(Jsoup.parse(escaped).select("script").size == 1)
    val challenge = Jsoup.parse("""<form method="post" action="/n/abc"><input type="hidden" name="_token" value="csrf"><input type="hidden" name="nonce" value="fresh"><div class="cf-turnstile" data-sitekey="test-key"></div></form>""")
    val gate = GatePage.prepareChallenge(challenge, "http://45.10.243.23/n/abc", selected)
    val html = GatePage.renderChallenge(gate)
    check(Jsoup.parse(html).selectFirst("form")!!.attr("target") == "_self")
    check(Jsoup.parse(html).selectFirst("input[name=nonce]")!!.attr("value") == "fresh")
    File(args[0]).writeText(html)

    val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
    val base = "http://127.0.0.1:${server.address.port}"
    val cookies = linkedMapOf<String, String>()
    val methods = mutableListOf<String>()
    server.createContext("/") { exchange ->
        methods += exchange.requestMethod
        when (exchange.requestURI.path) {
            "/movie" -> {
                exchange.responseHeaders.add("Set-Cookie", "session=fresh; Path=/; HttpOnly")
                exchange.responseHeaders.add("Set-Cookie", "second=value; Path=/")
                val b = "<html>movie</html>".toByteArray();exchange.sendResponseHeaders(200,b.size.toLong());exchange.responseBody.use { it.write(b) }
            }
            "/n/abc" -> {
                if (exchange.requestHeaders.getFirst("Cookie").orEmpty().contains("session=fresh")) {
                    exchange.responseHeaders.add("Location", "https://new-voe-domain.example/e/abc")
                    exchange.sendResponseHeaders(302,-1)
                } else exchange.sendResponseHeaders(403,-1)
            }
            "/relative" -> { exchange.responseHeaders.add("Location", "/n/abc");exchange.sendResponseHeaders(303,-1) }
            "/loop" -> { exchange.responseHeaders.add("Location", "/loop");exchange.sendResponseHeaders(302,-1) }
            else -> exchange.sendResponseHeaders(500,-1)
        }
        exchange.close()
    }
    server.start()
    try {
        val session = GateSession("$base/movie", "test-agent",
            { cookies.entries.joinToString("; ") { "${it.key}=${it.value}" } },
            { _, raw -> val pair=raw.substringBefore(';').split('=',limit=2);cookies[pair[0]]=pair[1] })
        check(session.get("$base/movie").response != null && cookies.size==2)
        check(session.get("$base/relative").target == "https://new-voe-domain.example/e/abc")
        check(runCatching { session.get("$base/loop") }.isFailure)
        check(runCatching { session.get("$base/error") }.isFailure)
        check(methods.all { it == "GET" })
    } finally { server.stop(0) }
    if (args.size>1) {
        val live=Jsoup.parse(File(args[1]),"UTF-8")
        val choices=SiteParser(movieUrl).streams(live)
        choices.forEach { GatePage.renderMint(GatePage.prepare(live,movieUrl,it)) }
        println("Current public movie: ${choices.size} session-bound source requests prepared.")
    }
    println("Gate regressions: PASS (fresh payload/CSRF, language selection, origin checks, cookies, redirects, optional manual form).")
}
