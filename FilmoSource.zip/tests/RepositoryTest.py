import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

spec = importlib.util.spec_from_file_location('assembly', Path(__file__).resolve().parents[1] / 'tools/assemble_repo.py')
assembly = importlib.util.module_from_spec(spec)
spec.loader.exec_module(assembly)


class RepositoryTests(unittest.TestCase):
    def test_series_and_movies_keep_bytes_versions_and_urls(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            inputs = []
            expected = {}
            for name, version in [('SerienStreamIP', 3), ('FilmoIP', 1)]:
                directory = root / name
                directory.mkdir()
                package = directory / (name + '.cs3')
                with zipfile.ZipFile(package, 'w') as archive:
                    archive.writestr('manifest.json', json.dumps({'version': version}))
                    archive.writestr('classes.dex', b'dex\n035\0example')
                manifest = {'name': name, 'internalName': name, 'version': version,
                            'url': 'https://raw.githubusercontent.com/owner/repo/builds/' + package.name,
                            'fileSize': package.stat().st_size}
                (directory / 'plugins.json').write_text(json.dumps([manifest]))
                inputs.append(directory)
                expected[name] = package.read_bytes()
            output = root / 'output'
            assembly.assemble(inputs, output)
            plugins = json.loads((output / 'plugins.json').read_text())
            self.assertEqual([(p['internalName'], p['version']) for p in plugins], [('SerienStreamIP', 3), ('FilmoIP', 1)])
            for plugin in plugins:
                self.assertEqual((output / (plugin['internalName'] + '.cs3')).read_bytes(), expected[plugin['internalName']])
            self.assertEqual(json.loads((output / 'repo.json').read_text())['pluginLists'],
                             ['https://raw.githubusercontent.com/owner/repo/builds/plugins.json'])
            with self.assertRaises(ValueError):
                assembly.assemble([inputs[0], inputs[0]], root / 'duplicate')
            bad = json.loads((inputs[1] / 'plugins.json').read_text())
            bad[0]['version'] = 99
            (inputs[1] / 'plugins.json').write_text(json.dumps(bad))
            with self.assertRaises(ValueError):
                assembly.assemble(inputs, root / 'badversion')


if __name__ == '__main__':
    unittest.main()
