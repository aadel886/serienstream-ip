// Exercise the actual form script against a mock Turnstile API, never a real CAPTCHA.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(process.argv[2], 'utf8');
const script = html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
function page() {
  let options, submissions = 0;
  const listeners = {};
  const form = { addEventListener: (name, callback) => { listeners[name] = callback; }, submit: () => submissions++ };
  const next = { disabled: true }, status = {}, challenge = { getAttribute: () => 'test-key' };
  const window = { turnstile: { render: (target, config) => { options = config; } } };
  const document = { getElementById: id => ({ gate: form, next, status, challenge })[id] };
  vm.runInNewContext(script, { window, document });
  window.onGateReady();
  return { next, status, options, count: () => submissions, click: () => listeners.submit({ preventDefault() {} }) };
}
const success = page();
assert.equal(success.count(), 0, 'Loading must not submit an unverified form');
success.click();
assert.equal(success.count(), 0, 'Continue must require a successful challenge callback');
success.options.callback('mock-verified-token');
assert.equal(success.count(), 1, 'A successful challenge should continue without another click');
success.options.callback('mock-verified-token');
success.click();
assert.equal(success.count(), 1, 'Duplicate callbacks and clicks must not send duplicate POSTs');
assert.equal(success.next.disabled, true);
const failure = page();
failure.options['error-callback']();
failure.click();
assert.equal(failure.count(), 0);
assert.match(failure.status.textContent, /Erneut versuchen/);
failure.options['expired-callback']();
failure.click();
assert.equal(failure.count(), 0);
assert.match(failure.status.textContent, /abgelaufen/);
failure.options.callback('fresh-mock-token');
assert.equal(failure.count(), 1);
console.log('Form script: PASS (manual confirmation, automatic handoff, duplicate suppression, errors and expiry).');

const mintScript = fs.readFileSync(process.argv[2]+'.mint.html','utf8').match(/<script>\s*([\s\S]*?)<\/script>/)[1];
function mintPage() {
  let xhr, navigation;
  class MockRequest {
    constructor(){xhr=this;this.headers={};}
    open(method,url,async){this.method=method;this.url=url;this.async=async;}
    setRequestHeader(name,value){this.headers[name]=value;}
    send(body){this.body=JSON.parse(body);}
  }
  const status={};
  const elements={status,endpoint:{value:'http://45.10.243.23/n'},csrf:{value:'fresh-csrf'},payload:{value:'DE-new'}};
  vm.runInNewContext(mintScript,{document:{getElementById:id=>elements[id]},XMLHttpRequest:MockRequest,window:{location:{assign:url=>navigation=url}}});
  return {xhr,status,navigation:()=>navigation};
}
const mint=mintPage();
assert.equal(mint.xhr.method,'POST');assert.equal(mint.xhr.url,'http://45.10.243.23/n');
assert.equal(mint.xhr.headers['X-CSRF-TOKEN'],'fresh-csrf');assert.deepEqual(mint.xhr.body,{p:'DE-new'});
assert.equal(mint.navigation(),undefined);
mint.xhr.status=200;mint.xhr.responseText=JSON.stringify({x:'legitimate_ticket-123'});mint.xhr.onload();
assert.equal(mint.navigation(),'http://45.10.243.23/n/legitimate_ticket-123');
for(const invalid of [{x:'https://foreign.example/'},{x:'../../login'},{}]){
  const test=mintPage();test.xhr.status=200;test.xhr.responseText=JSON.stringify(invalid);test.xhr.onload();
  assert.equal(test.navigation(),undefined);assert.match(test.status.textContent,/Erneut versuchen/);
}
for(const failureType of ['network','timeout','http','bad-json']){
  const test=mintPage();
  if(failureType==='network')test.xhr.onerror();
  if(failureType==='timeout')test.xhr.ontimeout();
  if(failureType==='http'){test.xhr.status=419;test.xhr.onload();}
  if(failureType==='bad-json'){test.xhr.status=200;test.xhr.responseText='<html>error</html>';test.xhr.onload();}
  assert.equal(test.navigation(),undefined);assert.match(test.status.textContent,/Erneut versuchen/);
}
console.log('Filmo ticket script: PASS (normal POST, CSRF, selected language, top-level handoff, invalid responses and network errors).');
