package com.custom.serienstreamip

import java.net.URI
import java.net.URLDecoder
import org.jsoup.nodes.Document

internal data class GateRequest(
    val stream: StreamButton,
    val action: String,
    val csrf: String,
    val token: String,
    val siteKey: String,
    val tier: String
)

/** Only the site's ordinary form and manual Turnstile widget; no embedded video player. */
internal object GatePage {
    fun sameOrigin(first: String, second: String): Boolean = runCatching {
        val a = URI(first)
        val b = URI(second)
        fun port(u: URI) = if (u.port >= 0) u.port else if (u.scheme == "https") 443 else 80
        a.scheme in setOf("http", "https") && a.scheme == b.scheme &&
            a.host != null && a.host.equals(b.host, true) && port(a) == port(b)
    }.getOrDefault(false)

    fun externalTarget(site: String, target: String): Boolean = runCatching {
        val uri = URI(target)
        val host = uri.host?.lowercase() ?: return false
        uri.scheme in setOf("http", "https") && uri.userInfo == null && !sameOrigin(site, target) &&
            host != "challenges.cloudflare.com" && !host.endsWith(".cloudflare.com")
    }.getOrDefault(false)

    fun freshStream(document: Document, episodeUrl: String, selected: StreamButton): StreamButton =
        SiteParser(episodeUrl).streams(document).firstOrNull {
            if (selected.id.isNotBlank()) it.id == selected.id
            else it.provider == selected.provider && it.language == selected.language
        } ?: error("Die ausgewählte Quelle ist nicht mehr vorhanden. Episode erneut öffnen.")

    fun prepare(document: Document, episodeUrl: String, selected: StreamButton): GateRequest {
        val fresh = freshStream(document, episodeUrl, selected)
        val form = document.selectFirst("#player-prepare-form")
            ?: error("Das Freigabeformular der Website hat sich geändert.")
        val action = URI(episodeUrl).resolve(form.attr("action")).toASCIIString()
        require(sameOrigin(episodeUrl, action) && URI(action).path == "/r") {
            "Unerwartete Adresse des Freigabeformulars."
        }
        require(sameOrigin(episodeUrl, fresh.url) && URI(fresh.url).path == "/r") {
            "Unerwartete Adresse der Quelle."
        }
        val token = URI(fresh.url).rawQuery.orEmpty().split('&').firstNotNullOfOrNull { part ->
            val bits = part.split('=', limit = 2)
            if (bits.size == 2 && bits[0] == "t") URLDecoder.decode(bits[1], "UTF-8") else null
        } ?: error("Die Website liefert keinen Freigabe-Link.")
        val csrf = form.selectFirst("input[name=_token]")?.attr("value").orEmpty()
        require(csrf.isNotBlank() && token.isNotBlank()) { "Die Website-Sitzung ist unvollständig." }
        val root = document.selectFirst("#episode-redirect-gate-root")
        return GateRequest(fresh, action, csrf, token,
            root?.attr("data-turnstile-sitekey").orEmpty(),
            root?.attr("data-redirect-gate-tier").orEmpty())
    }

    private fun html(value: String) = value.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")

    fun render(request: GateRequest): String {
        // The original HTTP site enables ALTCHA only in a secure context, i.e. not on this IP URL.
        require(request.tier in setOf("turnstile", "turnstile_altcha") && request.siteKey.isNotBlank()) {
            "Diese Freigabeart wird noch nicht unterstützt."
        }
        require(request.tier != "turnstile_altcha" || URI(request.action).scheme == "http") {
            "Die Website verlangt eine zusätzliche Freigabe, die noch nicht unterstützt wird."
        }
        return """<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{margin:0;padding:16px;background:#16181e;color:#fff;font:18px sans-serif;text-align:center}
button{padding:12px 24px;border:2px solid #aaa;border-radius:8px;background:#205b91;color:#fff;font:inherit}
button:focus{outline:4px solid #fff}button:disabled{opacity:.55}
#challenge{display:flex;justify-content:center;min-height:70px;margin:12px 0}
#status{min-height:2.5em;font-size:16px}p{margin:8px 0}
</style></head><body>
<p>Freigabe durch SerienStream</p><p>${html(request.stream.label)}</p>
<form id="gate" method="post" action="${html(request.action)}" target="_self">
<input type="hidden" name="_token" value="${html(request.csrf)}">
<input type="hidden" name="t" value="${html(request.token)}">
<div id="challenge" data-key="${html(request.siteKey)}"></div>
<p id="status" role="status">Bitte das CAPTCHA bestätigen. Danach geht es automatisch weiter.</p>
<button id="next" type="submit" disabled>Weiter zu Cloudstream</button>
</form>
<script>
(function(){
  var form=document.getElementById('gate'), next=document.getElementById('next');
  var status=document.getElementById('status'), ready=false, sent=false;
  function submit(){
    if(!ready||sent)return;
    sent=true;next.disabled=true;status.textContent='Freigabe wird geprüft …';
    form.submit();
  }
  form.addEventListener('submit',function(event){event.preventDefault();submit();});
  window.onGateReady=function(){
    window.turnstile.render('#challenge',{
      sitekey:document.getElementById('challenge').getAttribute('data-key'),theme:'dark',
      callback:function(){if(sent)return;ready=true;next.disabled=false;submit();},
      'expired-callback':function(){ready=false;sent=false;next.disabled=true;status.textContent='Freigabe abgelaufen. Bitte erneut bestätigen.';},
      'error-callback':function(){ready=false;next.disabled=true;status.textContent='CAPTCHA konnte nicht geladen werden. Bitte „Erneut versuchen“ wählen.';}
    });
  };
})();
</script>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js?onload=onGateReady&amp;render=explicit" async defer></script>
</body></html>"""
    }
}
