package com.custom.serienstreamip

import android.app.Activity
import android.app.Application
import android.app.Dialog
import android.content.Context
import android.content.ContextWrapper
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.lagradost.cloudstream3.ErrorLoadingException
import com.lagradost.cloudstream3.utils.extractorApis
import java.io.ByteArrayInputStream
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** The user completes the website's normal challenge in an Android WebView. */
class ManualGate(context: Context) : Application.ActivityLifecycleCallbacks {
    private val app = context.applicationContext as? Application
    private val main = Handler(Looper.getMainLooper())
    private var activity = WeakReference(findActivity(context))
    private var activeDialog: Dialog? = null
    private val mutex = Mutex()

    init { app?.registerActivityLifecycleCallbacks(this) }

    private fun findActivity(context: Context): Activity? {
        var current = context
        while (current is ContextWrapper) {
            if (current is Activity) return current
            val parent = current.baseContext
            if (parent === current) break
            current = parent
        }
        return current as? Activity
    }

    suspend fun resolve(episodeUrl: String): String? = mutex.withLock {
        suspendCancellableCoroutine { continuation ->
            main.post {
                if (!continuation.isActive) return@post
                try {
                    val host = activity.get()
                    if (host == null || host.isFinishing) {
                        continuation.resumeWithException(ErrorLoadingException("Cloudstream bitte neu öffnen; das CAPTCHA benötigt ein aktives App-Fenster."))
                        return@post
                    }
                    val done = AtomicBoolean(false)
                    val dialog = Dialog(host)
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                    val web = WebView(host)
                    web.id = View.generateViewId()
                    web.isFocusable = true
                    web.isFocusableInTouchMode = true
                    activeDialog = dialog
                    val television = host.resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK ==
                        Configuration.UI_MODE_TYPE_TELEVISION || host.packageManager.hasSystemFeature("amazon.hardware.fire_tv")
                    fun dp(value: Int) = (value * host.resources.displayMetrics.density + 0.5f).toInt()
                    val siteHost = Uri.parse(episodeUrl).host.orEmpty()
                    val streamHosts = extractorApis.mapNotNull {
                        Uri.parse(it.mainUrl).host?.lowercase()
                    }.filter { it.isNotEmpty() }.toSet()

                    fun recognizedStream(url: String): Boolean {
                        val parsed = Uri.parse(url)
                        if (parsed.scheme !in setOf("http", "https")) return false
                        val candidate = parsed.host?.lowercase() ?: return false
                        if (candidate == siteHost || candidate.endsWith(".cloudflare.com")) return false
                        return streamHosts.any { candidate == it || candidate.endsWith(".$it") }
                    }

                    fun finish(url: String?) {
                        if (!done.compareAndSet(false, true)) return
                        main.post {
                            dialog.setOnDismissListener(null)
                            web.stopLoading()
                            dialog.dismiss()
                            (web.parent as? ViewGroup)?.removeView(web)
                            web.destroy()
                            if (activeDialog === dialog) activeDialog = null
                            if (continuation.isActive) continuation.resume(url)
                        }
                    }

                    continuation.invokeOnCancellation { finish(null) }
                    dialog.setOnDismissListener { finish(null) }
                    val layout = LinearLayout(host).apply {
                        orientation = LinearLayout.VERTICAL
                        setBackgroundColor(Color.rgb(22, 24, 30))
                        setPadding(dp(16), dp(8), dp(16), dp(8))
                    }
                    val instruction = TextView(host).apply {
                        text = if (television) {
                            "Sprache/Hoster wählen, CAPTCHA bestätigen, dann Weiter. Menü: zur Leiste · Zurück: abbrechen. Falls ein Feld nicht erreichbar ist, wird eine Maus benötigt."
                        } else {
                            "Sprache/Hoster auswählen, CAPTCHA selbst bestätigen und Weiter wählen. Danach übernimmt Cloudstream."
                        }
                        setTextColor(Color.WHITE)
                        setPadding(dp(4), dp(8), dp(4), dp(8))
                        textSize = if (television) 17f else 15f
                    }
                    val toolbar = LinearLayout(host).apply { orientation = LinearLayout.HORIZONTAL }
                    fun control(label: String, action: () -> Unit) = Button(host).apply {
                        id = View.generateViewId()
                        text = label
                        setAllCaps(false)
                        isFocusable = true
                        textSize = if (television) 16f else 13f
                        minWidth = 0
                        minimumWidth = 0
                        setTextColor(Color.WHITE)
                        fun shape(color: Int, stroke: Int) = GradientDrawable().apply {
                            setColor(color)
                            setCornerRadius(dp(8).toFloat())
                            setStroke(dp(2), stroke)
                        }
                        background = StateListDrawable().apply {
                            addState(intArrayOf(android.R.attr.state_focused), shape(Color.rgb(24, 93, 150), Color.WHITE))
                            addState(intArrayOf(android.R.attr.state_pressed), shape(Color.rgb(24, 93, 150), Color.WHITE))
                            addState(intArrayOf(), shape(Color.rgb(45, 49, 59), Color.rgb(68, 73, 85)))
                        }
                        setOnClickListener { action() }
                    }
                    val enterPage = control("Zur Webseite") { web.requestFocus() }
                    val pageUp = control("Seite ↑") { web.pageUp(false) }
                    val pageDown = control("Seite ↓") { web.pageDown(false) }
                    val close = control("Abbrechen") { finish(null) }
                    val controls = listOf(enterPage, pageUp, pageDown, close)
                    controls.forEachIndexed { index, button ->
                        button.nextFocusLeftId = controls[(index + controls.size - 1) % controls.size].id
                        button.nextFocusRightId = controls[(index + 1) % controls.size].id
                        button.nextFocusUpId = button.id
                        button.nextFocusDownId = web.id
                        toolbar.addView(button, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
                            setMargins(dp(3), dp(4), dp(3), dp(8))
                        })
                    }
                    web.nextFocusUpId = enterPage.id
                    // The native toolbar stays reachable even when an embedded frame owns focus.
                    dialog.setOnKeyListener { _, code, event ->
                        if (code == KeyEvent.KEYCODE_MENU) {
                            if (event.action == KeyEvent.ACTION_UP) enterPage.requestFocus()
                            true
                        } else false
                    }
                    layout.addView(instruction)
                    layout.addView(toolbar)
                    layout.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
                    web.settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        allowFileAccess = false
                        allowContentAccess = false
                        javaScriptCanOpenWindowsAutomatically = false
                        setSupportMultipleWindows(false)
                        mediaPlaybackRequiresUserGesture = true
                        loadWithOverviewMode = true
                        useWideViewPort = true
                    }
                    web.setWebChromeClient(WebChromeClient())
                    web.setWebViewClient(object : WebViewClient() {
                        @Suppress("DEPRECATION")
                        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                            if (recognizedStream(url)) {
                                finish(url)
                                return true
                            }
                            // Keep the dialog on the episode and allow challenge navigation.
                            if (url == "about:blank" || url == "about:srcdoc") return false
                            val uri = Uri.parse(url)
                            if (uri.scheme !in setOf("http", "https")) return true
                            val targetHost = uri.host.orEmpty()
                            return targetHost != siteHost && targetHost != "challenges.cloudflare.com"
                        }

                        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                            val acceptsHtml = request.requestHeaders.entries.any {
                                it.key.equals("Accept", true) && it.value.contains("text/html")
                            }
                            if (!request.isForMainFrame && acceptsHtml && recognizedStream(request.url.toString())) {
                                finish(request.url.toString())
                                return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                            }
                            return null
                        }

                        override fun onPageFinished(view: WebView, url: String) {
                            if (Uri.parse(url).host == siteHost) {
                                view.evaluateJavascript("(function(){var links=document.getElementById('episode-links');if(links){links.scrollIntoView();}})();", null)
                            }
                        }
                        // TLS errors use WebView's default cancellation; there is no trust-all handler.
                    })
                    dialog.setContentView(layout)
                    dialog.show()
                    dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    enterPage.requestFocus()
                    web.loadUrl(episodeUrl)
                } catch (error: Exception) {
                    activeDialog?.setOnDismissListener(null)
                    activeDialog?.dismiss()
                    activeDialog = null
                    if (continuation.isActive) continuation.resumeWithException(
                        ErrorLoadingException("Das CAPTCHA-Fenster konnte nicht geöffnet werden: ${error.message}")
                    )
                }
            }
        }
    }

    fun dispose() {
        app?.unregisterActivityLifecycleCallbacks(this)
        main.post { activeDialog?.dismiss(); activeDialog = null }
    }

    override fun onActivityResumed(value: Activity) { activity = WeakReference(value) }
    override fun onActivityCreated(value: Activity, state: Bundle?) { activity = WeakReference(value) }
    override fun onActivityDestroyed(value: Activity) { if (activity.get() === value) activity.clear() }
    override fun onActivityStarted(value: Activity) {}
    override fun onActivityPaused(value: Activity) {}
    override fun onActivityStopped(value: Activity) {}
    override fun onActivitySaveInstanceState(value: Activity, state: Bundle) {}
}
