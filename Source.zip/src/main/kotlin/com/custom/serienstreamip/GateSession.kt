package com.custom.serienstreamip

import java.net.URI
import org.jsoup.Connection
import org.jsoup.Jsoup

/** Ordinary GET requests using the same cookies and UA as the CAPTCHA WebView. */
internal class GateSession(
    private val episodeUrl: String,
    private val userAgent: String,
    private val readCookies: (String) -> String?,
    private val writeCookie: (String, String) -> Unit
) {
    data class Result(val response: Connection.Response?, val target: String?)

    fun get(url: String): Result {
        var current = url
        repeat(6) {
            if (GatePage.externalTarget(episodeUrl, current)) return Result(null, current)
            require(GatePage.sameOrigin(episodeUrl, current)) { "Unerwartete Weiterleitung der Website." }
            val connection = Jsoup.connect(current).userAgent(userAgent).referrer(episodeUrl)
                .timeout(20000).maxBodySize(4 * 1024 * 1024).followRedirects(false)
                .ignoreContentType(true).ignoreHttpErrors(true)
            readCookies(current)?.takeIf { it.isNotBlank() }?.let { connection.header("Cookie", it) }
            val response = connection.execute()
            response.multiHeaders().entries.filter { it.key.equals("Set-Cookie", true) }
                .flatMap { it.value }.forEach { writeCookie(current, it) }
            if (response.statusCode() in setOf(301, 302, 303, 307, 308)) {
                val location = response.header("Location") ?: error("Weiterleitungsadresse fehlt.")
                current = URI(current).resolve(location).toASCIIString()
            } else {
                require(response.statusCode() in 200..299) { "Website antwortet mit HTTP ${response.statusCode()}." }
                return Result(response, null)
            }
        }
        error("Zu viele Weiterleitungen der Website.")
    }
}
