package com.custom.serienstreamip

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.LoadResponse.Companion.addActors
import com.lagradost.cloudstream3.LoadResponse.Companion.addTrailer
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.loadExtractor
import com.lagradost.cloudstream3.utils.extractorApis
import com.lagradost.cloudstream3.utils.newExtractorLink
import java.net.URLEncoder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document

class SerienStreamIpProvider(private val gate: ManualGate) : MainAPI() {
    override var name = "SerienStream IP"
    override var mainUrl = "http://186.2.175.5"
    override var lang = "de"
    override val supportedTypes = setOf(TvType.TvSeries)
    override val hasMainPage = true

    private val parser get() = SiteParser(mainUrl)

    private suspend fun document(url: String): Document = withContext(Dispatchers.IO) {
        Jsoup.connect(url)
            .userAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/130.0.0.0 Mobile Safari/537.36")
            .timeout(25000)
            .maxBodySize(4 * 1024 * 1024)
            .get()
    }

    private fun ShowCard.toSearch(): SearchResponse = newTvSeriesSearchResponse(title, url) {
        posterUrl = poster
    }

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val rows = parser.home(document("${mainUrl.trimEnd('/')}/beliebte-serien"))
        if (rows.isEmpty()) throw ErrorLoadingException("Keine Serien gefunden. Möglicherweise hat sich die Website geändert.")
        return newHomePageResponse(rows.map { (title, cards) ->
            HomePageList(title, cards.map { it.toSearch() })
        }, hasNext = false)
    }

    override suspend fun search(query: String): List<SearchResponse> {
        if (query.isBlank()) return emptyList()
        val term = URLEncoder.encode(query.trim(), "UTF-8")
        return parser.search(document("${mainUrl.trimEnd('/')}/suche?term=$term&tab=shows"))
            .map { it.toSearch() }
    }

    override suspend fun load(url: String): LoadResponse {
        val currentParser = parser
        val canonical = currentParser.showUrl(url) ?: throw ErrorLoadingException("Ungültige Serienadresse.")
        val doc = document(canonical)
        val metadata = doc.selectFirst(".show-header-wrapper")
            ?: throw ErrorLoadingException("Die Serienbeschreibung konnte nicht gelesen werden.")
        val title = metadata.selectFirst("h1")?.text()?.takeIf { it.isNotBlank() }
            ?: throw ErrorLoadingException("Serientitel fehlt.")
        val cover = currentParser.poster(metadata)
        val releaseYear = metadata.selectFirst("a[href^=/jahr/]")?.text()?.toIntOrNull()
        val description = metadata.selectFirst(".description-text")?.text()
        val genres = metadata.select("li.series-group:contains(Genre:) a").map { it.text() }
        val actors = metadata.select("li.series-group:contains(Besetzung:) a").map { it.text() }
        val trailer = metadata.selectFirst("[data-trailer-url]")?.attr("data-trailer-url")
        val seasons = currentParser.seasons(doc)
        if (seasons.isEmpty()) throw ErrorLoadingException("Keine Staffelliste gefunden.")

        // At most three season requests at once. Reuse the first page after its redirect.
        val limit = Semaphore(3)
        val rows = coroutineScope {
            seasons.map { season -> async {
                limit.withPermit {
                    val seasonDoc = if (doc.location().trimEnd('/') == season.url.trimEnd('/')) doc else document(season.url)
                    currentParser.episodes(seasonDoc, season.number)
                }
            }}.awaitAll().flatten()
        }.distinctBy { it.url }.sortedWith(compareBy({ it.season }, { it.number }))

        val episodes = rows.map { row -> newEpisode(row.url) {
            name = row.title
            season = row.season
            episode = row.number
        }}
        return newTvSeriesLoadResponse(title, canonical, TvType.TvSeries, episodes) {
            posterUrl = cover
            year = releaseYear
            plot = description
            tags = genres
            addActors(actors)
            addTrailer(trailer)
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val episodeUrl = parser.absolute(data) ?: return false
        val doc = document(episodeUrl)
        val buttons = parser.streams(doc)
        if (buttons.isEmpty()) throw ErrorLoadingException("Für diese Episode wurden keine Hoster gefunden.")
        val resolved = gate.resolve(episodeUrl, buttons) ?: return false
        val links = mutableListOf<ExtractorLink>()
        val collect: (ExtractorLink) -> Unit = { links.add(it) }

        // The website identifies the hoster even when its redirect uses a new mirror domain.
        val extractor = extractorApis.firstOrNull { it.name.equals(resolved.stream.provider, true) }
        try {
            extractor?.getUrl(resolved.url, episodeUrl, subtitleCallback, collect)
        } catch (cancel: CancellationException) {
            throw cancel
        } catch (_: Exception) {
            // The normal URL-based resolver remains a fallback for other supported hosters.
        }
        if (links.isEmpty()) {
            try {
                loadExtractor(resolved.url, episodeUrl, subtitleCallback, collect)
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (_: Exception) {
                // A specific failure is reported below, rather than opening a browser player.
            }
        }
        if (links.isEmpty()) throw ErrorLoadingException(
            "Die Freigabe wurde übergeben, aber ${resolved.stream.provider} liefert keinen abspielbaren Stream. " +
                "Cloudstream aktualisieren oder eine andere Quelle wählen."
        )
        for (link in links.distinctBy { Triple(it.url, it.quality, it.type) }) {
            callback(newExtractorLink(
                source = resolved.stream.provider,
                name = "${resolved.stream.label} · ${link.name}",
                url = link.url,
                type = link.type
            ) {
                referer = link.referer
                quality = link.quality
                headers = link.headers
                extractorData = link.extractorData
            })
        }
        return true
    }
}
