package com.custom.serienstreamip

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class SerienStreamIpPlugin : Plugin() {
    private var gate: ManualGate? = null

    override fun load(context: Context) {
        val resolver = ManualGate(context)
        gate = resolver
        registerMainAPI(SerienStreamIpProvider(resolver))
    }

    override fun beforeUnload() {
        gate?.dispose()
        gate = null
    }
}
