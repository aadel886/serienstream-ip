package com.custom.serienstreamip

import java.net.URI
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

internal data class ShowCard(val title: String, val url: String, val poster: String?)
internal data class SeasonPage(val number: Int, val url: String)
internal data class EpisodeRow(val season: Int, val number: Int, val title: String, val url: String)
internal data class StreamButton(val url: String, val provider: String, val language: String, val id: String = "") {
    val label get() = "$provider [$language]"
}

/** Parsers for the public SerienStream v2 HTML. No cached player tokens. */
internal class SiteParser(private val baseUrl: String) {
    private val base = URI(baseUrl.trimEnd('/') + "/")
    private val seriesPath = Regex("^/serie/[^/]+")
    private val seasonPath = Regex("/staffel-(\\d+)")
    private val episodePath = Regex("/episode-(\\d+)")
    private val location = Regex("(?:window\\.)?location(?:\\.href)?\\s*=\\s*['\"]([^'\"]+)['\"]")

    fun absolute(raw: String?): String? {
        val value = raw?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        return runCatching {
            val result = base.resolve(value)
            if (result.scheme !in setOf("http", "https")) return null
            result.toASCIIString()
        }.getOrNull()
    }

    fun showUrl(raw: String?): String? {
        val url = absolute(raw) ?: return null
        val path = seriesPath.find(URI(url).path)?.value ?: return null
        return base.resolve(path).toASCIIString()
    }

    fun poster(element: Element?): String? {
        val img = element?.selectFirst("img") ?: return null
        return absolute(img.attr("data-src").ifBlank { img.attr("src") })
    }

    fun card(element: Element): ShowCard? {
        val anchor = if (element.tagName() == "a") element else element.selectFirst("a[href]")
        val url = showUrl(anchor?.attr("href")) ?: return null
        val title = element.selectFirst("img")?.attr("alt")?.trim().orEmpty()
            .ifBlank { element.selectFirst(".show-title, h3, h6")?.text().orEmpty() }
        if (title.isBlank()) return null
        return ShowCard(title, url, poster(element))
    }

    fun home(document: Document): List<Pair<String, List<ShowCard>>> =
        document.select(".popular-page > div").mapNotNull { section ->
            val cards = section.select("a.show-card").mapNotNull(::card).distinctBy { it.url }
            val title = section.selectFirst("h2, h3, h4")?.text().orEmpty().trim()
            if (cards.isEmpty()) null else (title.ifBlank { "Weitere Serien" } to cards)
        }

    fun search(document: Document): List<ShowCard> = document
        .select(".results-group .card").mapNotNull(::card).distinctBy { it.url }

    fun seasons(document: Document): List<SeasonPage> = document
        .select("#season-nav a[href]").mapNotNull { link ->
            val url = absolute(link.attr("href")) ?: return@mapNotNull null
            val number = seasonPath.find(URI(url).path)?.groupValues?.get(1)?.toIntOrNull()
                ?: return@mapNotNull null
            SeasonPage(number, url)
        }.distinctBy { it.number }.sortedBy { it.number }

    fun episodes(document: Document, season: Int): List<EpisodeRow> = document
        .select(".episode-section .episode-row").mapNotNull { row ->
            val raw = row.selectFirst("a[href*=/episode-]")?.attr("href")
                ?: location.find(row.attr("onclick"))?.groupValues?.get(1)
            val url = absolute(raw) ?: return@mapNotNull null
            val number = episodePath.find(URI(url).path)?.groupValues?.get(1)?.toIntOrNull()
                ?: return@mapNotNull null
            val title = row.selectFirst(".episode-title-ger")?.text().orEmpty()
                .ifBlank { row.selectFirst(".episode-title-eng")?.text().orEmpty() }
                .ifBlank { row.selectFirst(".episode-title-cell")?.text().orEmpty() }
                .ifBlank { "Episode $number" }
            EpisodeRow(season, number, title, url)
        }.distinctBy { it.url }.sortedBy { it.number }

    fun streams(document: Document): List<StreamButton> = document
        .select(".link-wrapper > button[data-play-url]").mapNotNull { button ->
            val url = absolute(button.attr("data-play-url")) ?: return@mapNotNull null
            StreamButton(url, button.attr("data-provider-name"), button.attr("data-language-label"), button.attr("data-link-id"))
        }.distinctBy { it.url }

    fun hasGate(document: Document): Boolean {
        val tier = document.selectFirst("#episode-redirect-gate-root")
            ?.attr("data-redirect-gate-tier").orEmpty()
        return tier.isNotBlank() && tier != "none"
    }
}
