package com.custom.serienstreamip

import com.sun.net.httpserver.HttpServer
import java.io.File
import java.net.InetSocketAddress
import org.jsoup.Jsoup

fun main(args: Array<String>) {
    val episode = "http://186.2.175.5/serie/demo/staffel-1/episode-1"
    val document = Jsoup.parse("""
      <div id="episode-redirect-gate-root" data-redirect-gate-tier="turnstile" data-turnstile-sitekey="test-key"></div>
      <div class="link-wrapper">
        <button data-link-id="de" data-play-url="/r?t=NEW%2Bde%3D" data-provider-name="VOE" data-language-label="Deutsch"></button>
        <button data-link-id="en" data-play-url="/r?t=NEW%2Ben%3D" data-provider-name="VOE" data-language-label="Englisch"></button>
      </div>
      <form id="player-prepare-form" action="/r" target="player-iframe">
        <input name="_token" value="fresh-session-token">
      </form>
    """, episode)
    val old = StreamButton("http://186.2.175.5/r?t=OLD", "VOE", "Englisch", "en")
    val request = GatePage.prepare(document, episode, old)
    check(request.token == "NEW+en=") // Fresh token, correct language, decoded once.
    check(request.csrf == "fresh-session-token")
    val html = GatePage.render(request)
    val rendered = Jsoup.parse(html)
    check(rendered.select("iframe, video").isEmpty())
    check(rendered.selectFirst("form")!!.attr("target") == "_self")
    check(rendered.selectFirst("form")!!.attr("action") == "http://186.2.175.5/r")
    check(rendered.selectFirst("input[name=t]")!!.attr("value") == "NEW+en=")
    check(rendered.select("script[src]").single().attr("src").startsWith("https://challenges.cloudflare.com/"))
    check(GatePage.externalTarget(episode, "https://new-voe-mirror.example/e/123"))
    check(!GatePage.externalTarget(episode, "https://challenges.cloudflare.com/turnstile/x"))
    check(!GatePage.externalTarget(episode, "javascript:alert(1)"))
    check(!GatePage.externalTarget(episode, "https://user:password@host.example/x"))
    check(!GatePage.sameOrigin(episode, "http://186.2.175.5:8080/r"))
    check(GatePage.sameOrigin(episode, "http://186.2.175.5:80/r"))
    val changed = document.clone()
    changed.selectFirst("form")!!.attr("action", "https://elsewhere.example/steal")
    check(runCatching { GatePage.prepare(changed, episode, old) }.isFailure)
    check(runCatching { GatePage.prepare(document, episode, old.copy(id = "missing")) }.isFailure)
    val escaped = GatePage.render(request.copy(token = "</script><script>alert(1)</script>\"&+", csrf = "\"&<"))
    val parsedEscaped = Jsoup.parse(escaped)
    check(parsedEscaped.selectFirst("input[name=t]")!!.attr("value") == "</script><script>alert(1)</script>\"&+")
    check(parsedEscaped.select("script").size == 2)
    File(args[0]).writeText(html)

    // Real HTTP redirect/cookie regression, but no real CAPTCHA or video host is contacted.
    val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
    val base = "http://127.0.0.1:${server.address.port}"
    val receivedCookies = mutableListOf<String>()
    val methods = mutableListOf<String>()
    server.createContext("/") { exchange ->
        methods += exchange.requestMethod
        receivedCookies += exchange.requestHeaders.getFirst("Cookie").orEmpty()
        when (exchange.requestURI.path) {
            "/episode" -> {
                exchange.responseHeaders.add("Set-Cookie", "session=fresh; Path=/; HttpOnly")
                exchange.responseHeaders.add("Set-Cookie", "other=value; Path=/")
                val body = document.outerHtml().toByteArray()
                exchange.sendResponseHeaders(200, body.size.toLong())
                exchange.responseBody.use { it.write(body) }
            }
            "/start" -> {
                exchange.responseHeaders.add("Location", "/r")
                exchange.sendResponseHeaders(302, -1)
            }
            "/r" -> {
                if (exchange.requestHeaders.getFirst("Cookie").orEmpty().contains("session=fresh")) {
                    exchange.responseHeaders.add("Location", "https://new-voe-mirror.example/e/123")
                    exchange.sendResponseHeaders(303, -1)
                } else exchange.sendResponseHeaders(403, -1)
            }
            "/gate" -> {
                val body = "<script>parent.postMessage({type:'frameBridge'},'*')</script>".toByteArray()
                exchange.sendResponseHeaders(200, body.size.toLong())
                exchange.responseBody.use { it.write(body) }
            }
            "/loop" -> {
                exchange.responseHeaders.add("Location", "/loop")
                exchange.sendResponseHeaders(302, -1)
            }
            else -> exchange.sendResponseHeaders(500, -1)
        }
        exchange.close()
    }
    server.start()
    try {
        val cookies = linkedMapOf<String, String>()
        val session = GateSession("$base/episode", "test-agent",
            { cookies.entries.joinToString("; ") { "${it.key}=${it.value}" } },
            { _, raw -> val pair = raw.substringBefore(';').split('=', limit = 2); cookies[pair[0]] = pair[1] })
        check(session.get("$base/episode").response != null)
        check(cookies.size == 2)
        check(session.get("$base/start").target == "https://new-voe-mirror.example/e/123")
        check(receivedCookies.last().contains("session=fresh"))
        check(session.get("$base/gate").response!!.body().contains("frameBridge"))
        check(runCatching { session.get("$base/loop") }.isFailure)
        check(methods.all { it == "GET" }) // We never submit or solve a CAPTCHA in the resolver.
    } finally { server.stop(0) }
    if (args.size > 1) {
        val live = Jsoup.parse(File(args[1]), "UTF-8")
        val choices = SiteParser(episode).streams(live)
        check(choices.isNotEmpty())
        choices.forEach { GatePage.render(GatePage.prepare(live, episode, it)) }
        println("Current public episode: ${choices.size} challenge forms prepared; no CAPTCHA submitted.")
    }
    println("Gate regressions: PASS (source identity, new tokens, main-frame form, escaping, mirror URLs, cookies, redirects, errors).")
}
