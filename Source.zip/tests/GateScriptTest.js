// Exercise the actual form script against a mock Turnstile API, never a real CAPTCHA.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(process.argv[2], 'utf8');
const script = html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
function page() {
  let options, submissions = 0;
  const listeners = {};
  const form = { addEventListener: (name, callback) => { listeners[name] = callback; }, submit: () => submissions++ };
  const next = { disabled: true }, status = {}, challenge = { getAttribute: () => 'test-key' };
  const window = { turnstile: { render: (target, config) => { options = config; } } };
  const document = { getElementById: id => ({ gate: form, next, status, challenge })[id] };
  vm.runInNewContext(script, { window, document });
  window.onGateReady();
  return { next, status, options, count: () => submissions, click: () => listeners.submit({ preventDefault() {} }) };
}
const success = page();
assert.equal(success.count(), 0, 'Loading must not submit an unverified form');
success.click();
assert.equal(success.count(), 0, 'Continue must require a successful challenge callback');
success.options.callback('mock-verified-token');
assert.equal(success.count(), 1, 'A successful challenge should continue without another click');
success.options.callback('mock-verified-token');
success.click();
assert.equal(success.count(), 1, 'Duplicate callbacks and clicks must not send duplicate POSTs');
assert.equal(success.next.disabled, true);
const failure = page();
failure.options['error-callback']();
failure.click();
assert.equal(failure.count(), 0);
assert.match(failure.status.textContent, /Erneut versuchen/);
failure.options['expired-callback']();
failure.click();
assert.equal(failure.count(), 0);
assert.match(failure.status.textContent, /abgelaufen/);
failure.options.callback('fresh-mock-token');
assert.equal(failure.count(), 1);
console.log('Form script: PASS (manual confirmation, automatic handoff, duplicate suppression, errors and expiry).');
