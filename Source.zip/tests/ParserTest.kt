package com.custom.serienstreamip

import java.io.File
import org.jsoup.Jsoup

fun main(args: Array<String>) {
    val parser = SiteParser("http://186.2.175.5")
    val card = Jsoup.parse("""<a class="show-card" href="/serie/demo/staffel-2"><img alt="Demo" src="data:image/gif;base64,x" data-src="/cover.jpg"></a>""")
    val item = parser.card(card.selectFirst("a")!!)!!
    check(item.url == "http://186.2.175.5/serie/demo")
    check(item.poster == "http://186.2.175.5/cover.jpg")
    check(parser.absolute("javascript:alert(1)") == null)
    check(parser.showUrl("/login") == null)

    val page = Jsoup.parse("""
        <nav id="season-nav"><a href="/serie/demo/staffel-2">2</a><a href="/serie/demo/staffel-0">Specials</a></nav>
        <section class="episode-section"><table>
          <tr class="episode-row" onclick="window.location.href='/serie/demo/staffel-0/episode-4';"><td class="episode-title-cell"><strong class="episode-title-ger">Vierte Folge</strong></td></tr>
          <tr class="episode-row" onclick="window.location='/serie/demo/staffel-0/episode-1'"><td class="episode-title-eng">First episode</td></tr>
        </table></section>
        <div id="episode-redirect-gate-root" data-redirect-gate-tier="turnstile"></div>
        <div class="link-wrapper"><button data-play-url="/r?t=a%2Bb" data-provider-name="VOE" data-language-label="Deutsch"></button></div>
    """)
    check(parser.seasons(page).map { it.number } == listOf(0, 2))
    val episodes = parser.episodes(page, 0)
    check(episodes.map { it.number } == listOf(1, 4))
    check(episodes.first().url == "http://186.2.175.5/serie/demo/staffel-0/episode-1")
    check(episodes.last().title == "Vierte Folge")
    check(parser.streams(page).single().url.endsWith("/r?t=a%2Bb"))
    check(parser.hasGate(page))
    check(!parser.hasGate(Jsoup.parse("<div>ordinary page</div>")))
    println("Parser regression checks: PASS (cards, lazy images, URL handling, specials, episode order, gate).")

    // Optional locally fetched pages, never packaged or uploaded with this repository.
    if (args.isNotEmpty()) {
        val prefix = args[0]
        val home = parser.home(Jsoup.parse(File("${prefix}-popular.html"), "UTF-8"))
        val search = parser.search(Jsoup.parse(File("${prefix}-search.html"), "UTF-8"))
        val show = Jsoup.parse(File("${prefix}-show.html"), "UTF-8")
        val episode = Jsoup.parse(File("${prefix}-episode.html"), "UTF-8")
        check(home.isNotEmpty() && home.first().second.isNotEmpty())
        check(search.isNotEmpty())
        check(parser.seasons(show).size == 2)
        check(parser.episodes(show, 1).size == 8)
        check(parser.streams(episode).size == 2)
        check(parser.hasGate(episode))
        println("Live HTML: ${home.size} homepage rows, ${search.size} search cards, 2 seasons, 8 first-season episodes, 2 stream buttons; CAPTCHA gate confirmed.")
    }
}
