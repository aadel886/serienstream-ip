# SerienStream IP für Cloudstream – Testversion

Eigene Android-Erweiterung für **http://186.2.175.5/** mit Serienübersicht,
Suche, Vorschaubildern, Beschreibungen und Staffeln/Episoden.

**Stand: 2. November 2026, Plugin-Version 2.** Die Erweiterung wurde kompiliert
und mit den am 2. November erfassten Website-Seiten geprüft.
**Die Wiedergabe und das CAPTCHA-Fenster wurden
noch nicht auf einem Android-Gerät getestet.** Sie ist deshalb ausdrücklich
eine Testversion für die aktuelle Cloudstream-Vorabversion.

Die Website verlangt bei der Stream-Weiterleitung derzeit ein CAPTCHA.
Die Erweiterung öffnet dafür die Episode in einem eingebetteten Browser.
Du wählst dort Sprache/Hoster, bestätigst das CAPTCHA selbst und drückst
„Weiter“. Erkennt Cloudstream den freigegebenen Hoster, wird sein Link an
den vorhandenen Cloudstream-Extractor weitergegeben. Der Erfolg hängt
auch vom Hoster und dessen Unterstützung in deiner App-Version ab.

## In Cloudstream installieren

Repo-Link: https://raw.githubusercontent.com/aadel886/serienstream-ip/builds/repo.json

In Cloudstream **Einstellungen → Erweiterungen → Repository hinzufügen** öffnen,
den Link einfügen und **SerienStream IP** installieren. Aktuelle Cloudstream-
Vorabversion erforderlich. Wiedergabe und CAPTCHA sind noch nicht am Gerät getestet.

## Funktionen

| Funktion | Aktueller Stand |
| --- | --- |
| Serienübersicht mit Kategorien | Eingebaut; 30 Kategorien in der Testseite erkannt |
| Suche nach Serien | Eingebaut, einschließlich Umlauten und Leerzeichen |
| Poster, Beschreibung, Jahr und Genres | Werden übernommen, soweit auf der Website vorhanden |
| Staffeln und Episoden | Eingebaut, einschließlich Specials/Staffel 0 und numerischer Sortierung |
| Sprache und Hoster | Im Freigabefenster auswählbar, soweit die Episode diese anbietet |
| Stream-Übergabe | Verwendet vorhandene Cloudstream-Extractoren; Wiedergabe noch nicht am Gerät bestätigt |
| Manuelles CAPTCHA-Fenster | Eingebaut, mit Fernbedienungsleiste in Version 2 |
| Automatische Plugin-Updates | Nach Veröffentlichung und Installation über den Repo-Link; bei lokalen Dateien manuell |

Favoriten, Wiedergabefortschritt und Player-Bedienung gehören zur Cloudstream-App.
Die Erweiterung liefert ihr dafür die Serien und Episoden. Videoqualität,
Tonspuren und Untertitel hängen vom jeweiligen Stream ab; 4K ist nicht garantiert.
Änderungen der Website werden nicht automatisch repariert: Dafür braucht es
eine neue Plugin-Version.

## Nutzung auf Fire TV

Cloudstream dokumentiert die Installation auf Fire TV. Für dieses Plugin ist
ein **Android-basiertes Gerät mit mindestens API 23** erforderlich. Fire OS 6
und neuer erfüllen die API-Voraussetzung. Fire OS 5 (API 22) ist für diesen
Build zu alt. **Vega OS ist kein Android:** Auf Geräten wie dem Fire TV Stick
4K Select laufen die Android-APK und dieses CS3-Plugin nicht.

Auf einem passenden Fire-TV-Gerät zeigt Cloudstream die Serien, Suche und
Episoden in seiner TV-Oberfläche. Im zusätzlichen Freigabefenster gibt es:

- **Zur Webseite:** Fokus auf die Website; dort mit Richtungstasten und OK navigieren.
- **Seite ↑ / Seite ↓:** die Website seitenweise verschieben.
- **Abbrechen** oder **Zurück:** Freigabe beenden.
- **Menütaste:** aus der Website zurück zur stets sichtbaren Bedienleiste.
- Weiße Umrandung und blauer Hintergrund für die aktuell fokussierte Schaltfläche.

Diese Anpassungen erleichtern die Bedienung, machen fremde Webseiten oder
CAPTCHA-Iframes aber nicht automatisch fernbedienungstauglich. Wenn ein
CAPTCHA-Feld mit Richtungstasten nicht erreichbar ist, kann eine verbundene
Maus nötig sein. Ob die Freigabe mit der WebView-Version deines Geräts klappt,
muss noch getestet werden. Es gibt keine automatische CAPTCHA-Lösung.

**Einschätzung:** Die native Seriennavigation ist ein sinnvoller TV-Ansatz.
Für bequemes, verlässliches Starten jeder Episode ist diese Testversion noch
nicht bestätigt. Ein älteres Gerät kann zusätzlich an einer alten Browser-Engine
scheitern, obwohl es die minimale Android-Version erfüllt.

## Direkt auf Android ausprobieren

1. Entpacke die ZIP-Datei. Die fertige Erweiterung liegt in
   **`dist/SerienStreamIP.cs3`**.
2. Kopiere diese Datei in den Ordner **`Cloudstream3/plugins`** im internen
   Speicher. Erstelle die Ordner, falls sie noch nicht existieren.
3. Erlaube Cloudstream gegebenenfalls in den Android-Einstellungen den
   Zugriff auf alle Dateien. Die App benötigt diesen für lokale Plugins.
4. Starte Cloudstream vollständig neu. Wähle als Quelle **SerienStream IP**.

Dieser lokale Weg benötigt kein GitHub-Konto. Es gibt dabei keine
automatischen Updates. Auch für den Fire TV wird zunächst die aktuelle
Cloudstream-Vorabversion benötigt; die Erweiterung wurde gegen deren API gebaut.

### Kurzer Test auf deinem Fire TV

1. Prüfe Modell und Betriebssystem unter **Einstellungen → Mein Fire TV → Info**.
2. Installiere das Plugin und öffne **SerienStream IP** als Quelle.
3. Suche eine Serie, öffne eine Staffel und starte eine Folge.
4. Prüfe im Freigabefenster Richtungstasten, OK, Menütaste und Zurück.
5. Wähle Sprache/Hoster, bestätige das CAPTCHA selbst und wähle Weiter.
6. Prüfe, ob Cloudstreams Player startet, Ton und Bild laufen und Pause/Spulen funktionieren.

Bei einem Fehler sind Gerätemodell, Fire-OS-Version, Cloudstream-Version und
der genaue fehlgeschlagene Schritt hilfreich. Keine Zugangsdaten oder
CAPTCHA-/Weiterleitungstoken weitergeben.

## Eigenen Repo-Link auf GitHub einrichten

1. Erstelle auf GitHub ein **öffentliches** Repository, z. B. `serienstream-ip`.
2. Lade den Inhalt dieses Projektordners ins Hauptverzeichnis hoch. Wichtig:
   **`.github/workflows/build.yml` muss mit dabei sein.** Ein bloßer Upload der
   ZIP-Datei reicht nicht. `build/`, `.build-cache/` und `dist/` werden nicht benötigt.
3. Unter **Actions** läuft „Build and publish Cloudstream repo“. Bei deaktivierten
   Actions zuerst Workflows erlauben. Der Workflow besitzt die erforderliche
   Schreibberechtigung über `permissions: contents: write`; übergeordnete
   Kontorichtlinien können diese dennoch begrenzen.
4. Nach einem erfolgreichen Lauf findest du den echten Repo-Link in der
   Zusammenfassung des Workflows. Er hat diese Form – ersetze beide Platzhalter:

   ```text
   https://raw.githubusercontent.com/DEIN_GITHUBNAME/DEIN_REPONAME/builds/repo.json
   ```

5. In Cloudstream: **Einstellungen → Erweiterungen → Repository hinzufügen**.
   Füge den Link ein und installiere **SerienStream IP** aus diesem Repo.

Der Workflow erstellt den Branch `builds` beim ersten Lauf selbst. Er erzeugt
`repo.json`, `plugins.json` und die kompilierte `.cs3`-Datei automatisch aus
deinem tatsächlichen Repositorynamen. Dieses Projekt ist unter
https://github.com/aadel886/serienstream-ip veröffentlicht. Die Platzhalter
oben sind nur für die Einrichtung eines eigenen Forks gedacht.

## Was geprüft wurde

- Kotlin-Quellcode erfolgreich gegen die Cloudstream-API kompiliert.
- Android-DEX und installierbares CS3-Archiv erzeugt.
- Regressionstests für Karten, verzögert geladene Bilder, relative Adressen,
  Specials/Staffel 0, Episodenreihenfolge und CAPTCHA-Erkennung bestanden.
- Aktuelle Live-HTML geprüft: 30 Kategorien auf der Übersichtsseite,
  24 unterschiedliche Suchtreffer für „planet“, 2 Staffeln der Testserie,
  8 Folgen in deren erster Staffel und 2 Hoster-Schaltflächen der Testepisode.
- **Offen:** Installation, CAPTCHA-Bedienung und vollständige Wiedergabe auf
  einem Android-/Fire-TV-Gerät; Ausführung des GitHub-Workflows auf einem echten Konto.

CAPTCHA-Freigaben werden nicht automatisch gelöst. Wenn die Website den
eingebetteten Browser ablehnt oder ein Hoster nicht in Cloudstreams
Extractor-Liste steht, kann die Wiedergabe scheitern. Es werden weder
Benutzerkonten noch Zugangsdaten benötigt oder mitgeliefert.

## Selbst bauen

Voraussetzungen: **Python 3.10+ und Java 17+**, Internetzugang für die
Build-Abhängigkeiten. Ein vollständiges Android SDK ist nicht erforderlich.

```bash
python tools/build.py
```

Mit Dateien für dein eigenes Online-Repository:

```bash
python tools/build.py --repo DEIN_GITHUBNAME/DEIN_REPONAME
```

Alle Ausgaben landen in `dist/`. Der Build kompiliert Kotlin, führt die
Parser-Tests aus und erzeugt mit Androids D8-Werkzeug das DEX-Format.
Das CS3-Archiv enthält ausschließlich unseren Plugin-Code und `manifest.json`;
die großen Build-Abhängigkeiten werden nicht darin ausgeliefert.

Die Downloads in `dependencies.json` sind mit SHA-256 abgesichert. Die
Cloudstream-Vorab-API liegt beim Hersteller an einer veränderlichen Adresse.
Wird sie ersetzt, stoppt ein frischer Build bei abweichender Prüfsumme.
Dann müssen die neue API und ihre Kompatibilität geprüft sowie ihre Prüfsumme
in `dependencies.json` aktualisiert werden; der Build ignoriert diesen Schutz
nicht automatisch. Bereits heruntergeladene passende Dateien bleiben im Cache.

## Projektdateien

| Datei | Aufgabe |
| --- | --- |
| `src/main/kotlin/.../SiteParser.kt` | Auswertung der Website |
| `src/main/kotlin/.../SerienStreamIpProvider.kt` | Cloudstream-Anbindung |
| `src/main/kotlin/.../ManualGate.kt` | Manuelles CAPTCHA-Fenster |
| `src/main/kotlin/.../SerienStreamIpPlugin.kt` | Registrierung des Plugins |
| `plugin.json` | Name, Version und Plugin-Metadaten |
| `tools/build.py` | Kompilierung, Tests und Repository-Dateien |
| `.github/workflows/build.yml` | Automatischer Build und Veröffentlichung |

Die Basisadresse steht in `SerienStreamIpProvider.kt` bei `mainUrl`.
Für ein Update erhöhe `version` in `plugin.json`, passe den Code an und lade
die Änderungen zu GitHub hoch. Externe Änderungen an der Website oder an
Cloudstreams Extractoren können spätere Anpassungen erforderlich machen.

## Technische Referenzen

- [Cloudstream: Entwicklung von Erweiterungen](https://recloudstream.github.io/csdocs/devs/gettingstarted/)
- [Cloudstream: Format eines JSON-Repositorys](https://recloudstream.github.io/csdocs/devs/create-your-own-json-repository/)
- [Cloudstream-Quellcode und API](https://github.com/recloudstream/cloudstream)
- [Cloudstream-Buildsystem und CS3-Format](https://github.com/recloudstream/gradle)
- [Cloudstream: Installation auf TV-Geräten](https://recloudstream.github.io/csdocs/other-devices/tv/)
- [Amazon: Fire-OS-Versionen und Geräte](https://developer.amazon.com/docs/fire-tv/fire-os-overview.html)
- [Amazon: Fire OS und Vega OS](https://developer.amazon.com/apps-and-games/blogs/2026/10/port-your-tv-app-to-react-native-with-adbt)
- [Cloudflare: Turnstile in WebViews](https://developers.cloudflare.com/turnstile/get-started/mobile-implementation/)
- [Kotlin](https://github.com/JetBrains/kotlin), [Jsoup](https://jsoup.org/),
  [Android R8/D8](https://r8.googlesource.com/r8),
  [Robolectric Android API-JAR](https://github.com/robolectric/robolectric)

Die Abhängigkeiten werden ausschließlich zum Kompilieren verwendet und
unterliegen den jeweiligen Lizenzen. Die Website-HTML, Bilder und Videos
sind nicht im Projektpaket enthalten.
